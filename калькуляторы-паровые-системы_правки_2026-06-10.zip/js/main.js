document.querySelectorAll(".acc__head").forEach((button) => {
  button.addEventListener("click", () => {
    const currentAcc = button.closest(".acc");
    const parentBody = currentAcc.parentElement;

    parentBody.querySelectorAll(":scope > .acc.is-open").forEach((acc) => {
      if (acc !== currentAcc) {
        acc.classList.remove("is-open");
      }
    });

    currentAcc.classList.toggle("is-open");
  });
});

/*
 * Движок калькуляторов: связывает HTML-форму с математикой (window.CALC).
 * Форму помечаем data-calc="<код>". Поля ввода — data-var (+ data-cat для единиц).
 * Поля результата — data-out (+ data-cat). Единица читается из выбранного радио
 * в соседнем .dropdown--measure (текст .form-radio-name).
 * Конкатенируется в build/js/main.js — без import/export.
 */
(function () {
  'use strict';

  // Символ выбранной единицы для поля с измерительным dropdown.
  // Читаем текст кнопки dropdown (его поддерживает в актуальном состоянии dropdown.js) —
  // это надёжнее, чем :checked, который ломается при совпадении name у разных групп радио.
  function unitSymbol(scope) {
    var btn = scope.querySelector('.dropdown--measure .dropdown__button');
    if (btn) { var t = btn.textContent.trim(); if (t) return t; }
    var checked = scope.querySelector('.dropdown--measure input:checked');
    if (!checked) return '';
    var lbl = checked.closest('label');
    var name = lbl && lbl.querySelector('.form-radio-name');
    return name ? name.textContent.trim() : '';
  }

  // Группа-обёртка поля (для поиска его dropdown единиц).
  function groupOf(el) {
    return el.closest('.form-item-group') || el.closest('.calculator-result-row') || el.parentNode;
  }

  function readInputs(form) {
    var U = window.Units;
    var inp = { fittings: {} };
    form.querySelectorAll('[data-var]').forEach(function (el) {
      var name = el.getAttribute('data-var');
      var dtype = el.getAttribute('data-type');
      // Класс трубопровода / произвольный селект-индекс — value выбранного радио
      if (dtype === 'grade' || dtype === 'select') {
        var rg = el.querySelector('input[type="radio"]:checked');
        inp[name] = rg ? parseInt(rg.value, 10) : 0;
        return;
      }
      // Размер трубы — резолвим в внутренний диаметр (м) по числу в подписи (DN80->80, 25A->25).
      // Радио value ненадёжен как индекс таблицы (списки на страницах разные), поэтому ищем по подписи.
      if (dtype === 'size') {
        var rs = el.querySelector('input[type="radio"]:checked');
        inp[name] = rs ? parseInt(rs.value, 10) : 0;
        var pipe = pipeFromSize(form, el);
        if (pipe) { inp.pipeInDiam = pipe.id / 1000; inp.pipeOutDiam = pipe.od / 1000; } // поле pipeInDiam (если есть) перезапишет ID ниже
        return;
      }
      var raw = (el.value || '').trim();
      var cat = el.getAttribute('data-cat');
      // Фитинги и прочие безразмерные счётчики
      if (name.indexOf('fit.') === 0) {
        inp.fittings[name.slice(4)] = raw === '' ? 0 : U.parseNum(raw);
        return;
      }
      if (!cat) { inp[name] = raw === '' ? null : U.parseNum(raw); return; }
      // Необязательная температура: пусто -> null (использовать насыщение)
      if (raw === '') { inp[name] = null; return; }
      inp[name] = U.toSI(raw, cat, unitSymbol(groupOf(el)));
    });
    return inp;
  }

  function renderOutputs(form, out) {
    var U = window.Units;
    form.querySelectorAll('[data-out]').forEach(function (el) {
      var name = el.getAttribute('data-out');
      var val = out[name];
      if (val === undefined || val === null) return;
      var cat = el.getAttribute('data-cat');
      if (!cat) { setFieldText(el, typeof val === 'number' ? formatNum(val) : val); return; } // без единиц: число форматируем, строку (размер трубы) как есть
      el.dataset.si = val; // сохраняем СИ для пересчёта при смене единицы
      var sym = unitSymbol(groupOf(el));
      setFieldText(el, formatNum(U.fromSI(val, cat, sym)));
    });
    var block = form.querySelector('.calculator-form__result');
    if (block) block.classList.add('is-filled');
    if (out.exceeded) flagExceeded(form);
  }

  function setFieldText(el, v) {
    if ('value' in el && el.tagName === 'INPUT') el.value = v;
    else el.textContent = v;
  }

  function formatNum(n) {
    if (!isFinite(n)) return '—';
    var a = Math.abs(n);
    if (a !== 0 && (a < 1e-3 || a >= 1e6)) return n.toExponential(4);
    return parseFloat(n.toPrecision(6)).toString();
  }

  function flagExceeded(form) {
    var msg = form.querySelector('[data-result-note]');
    if (msg) msg.textContent = 'Ни одна труба сортамента не укладывается в допустимые потери — показан наибольший типоразмер.';
  }

  // Символ единицы для конкретного radio (по тексту его .form-radio-name).
  function radioUnit(radio) {
    var lbl = radio.closest('label');
    var name = lbl && lbl.querySelector('.form-radio-name');
    return name ? name.textContent.trim() : '';
  }

  // Пересчёт поля результата при смене его единицы измерения.
  // Единицу берём из самого сработавшего radio (его .checked выставляется нативно
  // до любых слушателей), а не из текста кнопки dropdown — иначе ловим гонку:
  // обработчик движка регистрируется раньше dropdown.js и читает ещё старую подпись.
  function bindOutputUnitChange(form) {
    form.querySelectorAll('[data-out][data-cat]').forEach(function (el) {
      var grp = groupOf(el);
      grp.querySelectorAll('.dropdown--measure input').forEach(function (radio) {
        radio.addEventListener('change', function () {
          if (el.dataset.si === undefined) return;
          var sym = radioUnit(this) || unitSymbol(grp);
          setFieldText(el, formatNum(window.Units.fromSI(parseFloat(el.dataset.si), el.getAttribute('data-cat'), sym)));
        });
      });
    });
  }

  // Труба из PIPE_TABLE по выбранному размеру: ищем по числу в обозначении
  // (m: "80A" -> 80) совпадающему с числом в подписи (DN80/25A -> 80/25).
  function pipeFromSize(form, sizeEl) {
    if (!window.PIPE_TABLE) return null;
    var gradeEl = form.querySelector('[data-type="grade"]');
    var g = gradeEl ? (parseInt((gradeEl.querySelector('input:checked') || {}).value, 10) || 0) : 7;
    var checked = sizeEl.querySelector('input[type="radio"]:checked');
    if (!checked) return null;
    var nm = checked.closest('label').querySelector('.form-radio-name');
    var num = nm ? parseInt(nm.textContent.replace(/[^0-9]/g, ''), 10) : NaN;
    var list = window.PIPE_TABLE[g] || [];
    for (var i = 0; i < list.length; i++) {
      if (parseInt(list[i].m, 10) === num) return list[i];
    }
    return null;
  }
  // Внутренний диаметр (м) по выбранному размеру (для синхронизации поля).
  function diamFromSize(form, sizeEl) {
    var p = pipeFromSize(form, sizeEl);
    return p ? p.id / 1000 : null;
  }

  // Синхронизация поля внутреннего диаметра (если есть) при выборе класса/размера трубы.
  // Пользователь может переопределить значение вручную после синхронизации.
  function bindDiamSync(form) {
    var sizeEl = form.querySelector('[data-type="size"]');
    var diamField = form.querySelector('[data-var="pipeInDiam"]');
    if (!sizeEl || !diamField) return;
    var gradeEl = form.querySelector('[data-type="grade"]');
    function update() {
      var d = diamFromSize(form, sizeEl);
      if (d == null) return;
      diamField.value = formatNum(window.Units.fromSI(d, 'length', unitSymbol(groupOf(diamField))));
    }
    sizeEl.querySelectorAll('input').forEach(function (r) { r.addEventListener('change', update); });
    if (gradeEl) gradeEl.querySelectorAll('input').forEach(function (r) { r.addEventListener('change', update); });
    update();
  }

  // ----- Память значений между калькуляторами -----
  // Введённые значения (+ выбранная единица) сохраняются по data-var в localStorage,
  // чтобы при переходе на другой калькулятор общие поля (давление пара и т.п.) были
  // уже предзаполнены. Запоминаем только текстовые поля ввода; размер/класс трубы
  // (радио-группы) и синхронизируемый с размером pipeInDiam не трогаем.
  var MEM_KEY = 'calcFieldMemory';
  function memSkip(el) {
    var dt = el.getAttribute('data-type');
    if (dt === 'grade' || dt === 'select' || dt === 'size') return true;
    var name = el.getAttribute('data-var');
    return name === 'pipeInDiam' || name.indexOf('fit.') === 0;
  }
  function loadMem() { try { return JSON.parse(localStorage.getItem(MEM_KEY)) || {}; } catch (e) { return {}; } }
  function saveMem(m) { try { localStorage.setItem(MEM_KEY, JSON.stringify(m)); } catch (e) {} }
  // Выбрать в группе поля единицу по её символу (радио + нативно снимет выбор с соседей).
  function setGroupUnit(grp, sym) {
    if (!sym) return;
    grp.querySelectorAll('.dropdown--measure input[type="radio"]').forEach(function (r) {
      if (radioUnit(r) === sym) r.checked = true;
    });
  }
  function rememberField(el) {
    if (memSkip(el)) return;
    var raw = (el.value || '').trim();
    if (raw === '') return;
    var mem = loadMem();
    mem[el.getAttribute('data-var')] = { v: raw, u: el.getAttribute('data-cat') ? unitSymbol(groupOf(el)) : '' };
    saveMem(mem);
  }
  function restoreFields(form) {
    var mem = loadMem();
    form.querySelectorAll('input[data-var]').forEach(function (el) {
      if (memSkip(el)) return;
      var rec = mem[el.getAttribute('data-var')];
      if (!rec || rec.v == null || rec.v === '') return;
      if (rec.u) setGroupUnit(groupOf(el), rec.u); // до инициализации dropdown.js — подпись кнопки подхватится
      el.value = rec.v;
    });
  }
  function bindMemory(form) {
    form.querySelectorAll('input[data-var]').forEach(function (el) {
      if (memSkip(el)) return;
      el.addEventListener('input', function () { rememberField(el); });
      groupOf(el).querySelectorAll('.dropdown--measure input[type="radio"]').forEach(function (r) {
        r.addEventListener('change', function () { rememberField(el); });
      });
    });
  }

  function initForm(form) {
    var code = form.getAttribute('data-calc');
    if (!window.CALC || !window.CALC[code]) return;
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      try {
        renderOutputs(form, window.CALC[code](readInputs(form)));
      } catch (err) {
        if (window.console) console.error('Ошибка расчёта ' + code, err);
      }
    });
    // Память не должна ломать расчёт — изолируем в try/catch.
    try { restoreFields(form); } catch (e) { if (window.console) console.warn('restoreFields', e); }
    bindOutputUnitChange(form);
    bindDiamSync(form);
    try { bindMemory(form); } catch (e) { if (window.console) console.warn('bindMemory', e); }
  }

  // ----- Конвертор единиц: форма [data-convert="<категория>"] -----
  // Ввод значения + единица (dropdown в группе поля [data-conv-in]) -> таблица всех единиц категории
  // в контейнер [data-conv-results].
  function initConverter(form) {
    var cat = form.getAttribute('data-convert');
    var inEl = form.querySelector('[data-conv-in]');
    var box = form.querySelector('[data-conv-results]');
    if (!cat || !inEl || !box || !window.Units) return;
    function run() {
      var sym = unitSymbol(groupOf(inEl));
      var si = window.Units.toSI(inEl.value, cat, sym);
      box.innerHTML = '';
      if (!isFinite(si)) return;
      window.Units.list(cat).forEach(function (u) {
        var val = formatNum(window.Units.fromSI(si, cat, u));
        var row = document.createElement('div');
        row.className = 'calculator-result-row conv-row';
        row.innerHTML = '<span class="conv-row__unit">' + u + '</span><span class="conv-row__val">' + val + '</span>';
        box.appendChild(row);
      });
    }
    form.addEventListener('submit', function (e) { e.preventDefault(); run(); });
    inEl.addEventListener('input', run);
    groupOf(inEl).querySelectorAll('.dropdown--measure input').forEach(function (r) { r.addEventListener('change', run); });
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-calc]').forEach(initForm);
    document.querySelectorAll('[data-convert]').forEach(initConverter);
  });
})();

/*
 * Формулы калькуляторов. window.CALC['<код>'] принимает входы в СИ и возвращает выходы в СИ.
 * Опирается на window.SteamProps (IAPWS-IF97) и window.PIPE_TABLE (типоразмеры труб).
 * Видимые формулы взяты из formulas/tlv_app_reverse/calculators.json; коэффициент трения и
 * эквивалентные длины фитингов отсутствовали в данных — восстановлены стандартными корреляциями
 * и откалиброваны по эталонным расчётам TLV ToolBox.
 * Конкатенируется в build/js/main.js — без import/export.
 */
(function () {
  'use strict';

  // Глобалы резолвятся лениво (в момент вызова): при конкатенации этот файл идёт раньше
  // calc-steam-if97.js / calc-pipes-data.js, поэтому на этапе загрузки их ещё нет.
  function steam() { return (typeof window !== 'undefined' && window.SteamProps); }
  function pipes() { return (typeof window !== 'undefined' && window.PIPE_TABLE); }

  // Поправочный множитель трения: подгонка под TLV ToolBox (λ_TLV/λ_Колбрук = 1.006,
  // константа по 5 калибровочным точкам, Re 1.3e5..7e5, V 0.095..0.60).
  var FRICTION_CORR = 1.006;

  // Коэффициент трения Дарси по Колбрук-Уайту (итерация) с поправкой. epsd = ε/d.
  function colebrook(Re, epsd) {
    if (Re < 2300) return 64 / Re; // ламинарный режим
    var f = 0.02;
    for (var i = 0; i < 60; i++) {
      f = Math.pow(-2 * Math.log10(epsd / 3.7 + 2.51 / (Re * Math.sqrt(f))), -2);
    }
    return f * FRICTION_CORR;
  }

  // Коэффициенты местных сопротивлений K (метод TLV: L_eq = n·K·d/f).
  // Откалиброваны по эталонным расчётам TLV ToolBox (классические значения Crane).
  var K = { obsFlo: 10.5, thruFlo: 0.20, check: 2.40, elbow: 1.00 };
  function fittingsLength(d, f, fit) {
    fit = fit || {};
    var sumK = K.obsFlo * (fit.obsFlo || 0) + K.thruFlo * (fit.thruFlo || 0) +
      K.check * (fit.check || 0) + K.elbow * (fit.elbow || 0);
    return sumK * d / f; // эквивалентная длина фитингов, м
  }

  // Удельный объём пара V (м³/кг) и температура T (К): насыщение либо перегрев.
  function steamState(Pabs, Tk) {
    var S = steam(), Ts = S.Tsat(Pabs);
    if (Tk && Tk > Ts + 0.1) return { V: S.superheated(Pabs, Tk).v, T: Tk };
    return { V: S.satVapor(Pabs).v, T: Ts };
  }

  // Гидравлика для известной скорости v (м/с): Re, трение, эквивалентная длина, потери давления.
  // Универсально для любого флюида (V=уд. объём=1/ρ, eta=динам. вязкость Па·с).
  function hydraulics(d, v, V, eta, pipeLen, fit, eps) {
    var Re = v * d / (V * eta);
    var lam = colebrook(Re, eps / d);
    var leq = pipeLen + fittingsLength(d, lam, fit);
    var dp = lam * leq * v * v / (2 * d * V); // Па
    return { v: v, dp: dp, lam: lam, Re: Re, leq: leq };
  }
  // Скорость по массовому расходу (кг/ч) + потери (для пара).
  function velAndLoss(d, ms, V, eta, pipeLen, fit, eps) {
    var v = ms / 3600 * V / (Math.pow(d / 2, 2) * Math.PI);
    return hydraulics(d, v, V, eta, pipeLen, fit, eps);
  }
  function pipeArea(d) { return Math.pow(d / 2, 2) * Math.PI; }

  // ---- Свойства воды и газов ----
  // Удельный объём воды V (м³/кг) по T(К), p(МПа) — из IAPWS-IF97 область 1.
  function waterV(Pabs, Tk) { return steam().region1(Pabs, Tk).v; }
  // Динамическая вязкость воды (Па·с) по T(К). Корреляция 2.414e-5·10^(247.8/(T-140)).
  function waterVisc(Tk) { return 2.414e-5 * Math.pow(10, 247.8 / (Tk - 140)); }
  // Плотность воздуха (кг/м³): идеальный газ, R_возд=287.05 Дж/(кг·К). P в Па.
  function airRho(Ppa, Tk) { return Ppa / (287.05 * Tk); }
  // Динамическая вязкость воздуха (Па·с) — формула Сазерленда.
  function airVisc(Tk) { return 1.716e-5 * Math.pow(Tk / 273.15, 1.5) * (273.15 + 110.4) / (Tk + 110.4); }
  // Плотность произвольного газа (кг/м³): ρ=P·M/(R·T), M г/моль, P в Па.
  function gasRho(Ppa, Mgmol, Tk) { return Ppa * (Mgmol / 1000) / (8.31446 * Tk); }

  var CALC = {};

  /*
   * 11110 — Расчёт размера трубы по допустимым потерям давления (пар).
   * Вход (СИ): pipeGrade(idx), stmPress(МПа абс), stmTemp(К|null), stmFlow(кг/ч),
   *            allowPressLoss(Па), pipeLen(м), fittings{obsFlo,thruFlo,check,elbow}, pipeRough(м).
   * Выход (СИ): pipeSize(label), pipeInDiam(м), stmVelo(м/с), pressLoss(Па), equivLen(м), exceeded(bool).
   */
  CALC['11110'] = function (inp) {
    var S = steam(), PIPES = pipes();
    var st = steamState(inp.stmPress, inp.stmTemp);
    var V = st.V, eta = S.viscosity(1 / V, st.T);
    var eps = inp.pipeRough != null ? inp.pipeRough : 0.05e-3;
    var list = PIPES[inp.pipeGrade] || PIPES[7];
    var chosen = null;
    for (var i = 0; i < list.length; i++) {
      var d = list[i].id / 1000; // мм -> м
      var r = velAndLoss(d, inp.stmFlow, V, eta, inp.pipeLen, inp.fittings, eps);
      if (r.dp <= inp.allowPressLoss) { chosen = { pipe: list[i], d: d, r: r }; break; }
    }
    var exceeded = false;
    if (!chosen) { // ни одна труба не проходит — берём наибольшую
      var last = list[list.length - 1], dd = last.id / 1000;
      chosen = { pipe: last, d: dd, r: velAndLoss(dd, inp.stmFlow, V, eta, inp.pipeLen, inp.fittings, eps) };
      exceeded = true;
    }
    return {
      pipeSize: formatSize(inp.pipeGrade, chosen.pipe),
      pipeInDiam: chosen.d,            // м
      stmVelo: chosen.r.v,             // м/с
      pressLoss: chosen.r.dp,          // Па
      equivLen: chosen.r.leq,          // м
      exceeded: exceeded
    };
  };

  /*
   * 11150 — Скорость пара в трубе заданного диаметра.
   * Вход: pipeInDiam(м), stmPress(МПа абс), stmTemp(К|null), stmFlow(кг/ч). Выход: stmVelo(м/с).
   */
  CALC['11150'] = function (inp) {
    var V = steamState(inp.stmPress, inp.stmTemp).V;
    return { stmVelo: inp.stmFlow / 3600 * V / (Math.pow(inp.pipeInDiam / 2, 2) * Math.PI) };
  };

  /*
   * 11160 — Расход пара по скорости в трубе заданного диаметра.
   * Вход: pipeInDiam(м), stmPress, stmTemp, stmVelo(м/с). Выход: stmFlow(кг/ч).
   */
  CALC['11160'] = function (inp) {
    var V = steamState(inp.stmPress, inp.stmTemp).V;
    return { stmFlow: inp.stmVelo * Math.pow(inp.pipeInDiam / 2, 2) * Math.PI / V * 3600 };
  };

  /*
   * 11140 — Скорость и потери давления для трубы ЗАДАННОГО диаметра.
   * Вход: pipeInDiam(м), stmPress, stmTemp, stmFlow(кг/ч), pipeLen(м), fittings, pipeRough(м).
   * Выход: stmVelo(м/с), pressLoss(Па), equivLen(м).
   */
  CALC['11140'] = function (inp) {
    var S = steam();
    var st = steamState(inp.stmPress, inp.stmTemp);
    var eta = S.viscosity(1 / st.V, st.T);
    var eps = inp.pipeRough != null ? inp.pipeRough : 0.05e-3;
    var r = velAndLoss(inp.pipeInDiam, inp.stmFlow, st.V, eta, inp.pipeLen, inp.fittings, eps);
    return { stmVelo: r.v, pressLoss: r.dp, equivLen: r.leq };
  };

  /*
   * 11120 — Подбор размера трубы по допустимой скорости пара.
   * Вход: pipeGrade(idx), stmPress, stmTemp, stmFlow, upperVelo(м/с), pipeLen, fittings, pipeRough.
   * Выход: pipeSize, pipeInDiam(м), stmVelo, pressLoss(Па), equivLen(м), exceeded.
   */
  CALC['11120'] = function (inp) {
    var S = steam(), PIPES = pipes();
    var st = steamState(inp.stmPress, inp.stmTemp), V = st.V;
    var eta = S.viscosity(1 / V, st.T);
    var eps = inp.pipeRough != null ? inp.pipeRough : 0.05e-3;
    var list = PIPES[inp.pipeGrade] || PIPES[7];
    var chosen = null;
    for (var i = 0; i < list.length; i++) {
      var d = list[i].id / 1000;
      var r = velAndLoss(d, inp.stmFlow, V, eta, inp.pipeLen, inp.fittings, eps);
      if (r.v <= inp.upperVelo) { chosen = { pipe: list[i], d: d, r: r }; break; }
    }
    var exceeded = false;
    if (!chosen) { // даже наибольшая труба не укладывается в допустимую скорость
      var last = list[list.length - 1], dd = last.id / 1000;
      chosen = { pipe: last, d: dd, r: velAndLoss(dd, inp.stmFlow, V, eta, inp.pipeLen, inp.fittings, eps) };
      exceeded = true;
    }
    return {
      pipeSize: formatSize(inp.pipeGrade, chosen.pipe),
      pipeInDiam: chosen.d, stmVelo: chosen.r.v, pressLoss: chosen.r.dp,
      equivLen: chosen.r.leq, exceeded: exceeded
    };
  };

  // ----- Клапаны и сопла (методика IEC 60534 для сжимаемого потока) -----
  // FXT = Fγ·xT — откалибровано по TLV (Fγ≈1.010, xT=0.72). Расход в кг/ч при p в кПа, ρ в кг/м³.
  var FXT = 0.7275;
  // Массовый расход пара (кг/ч) через клапан с пропускной способностью Cv(US).
  function valveSteamFlow(Cv, p1kPa, p2kPa, rho) {
    var dp = p1kPa - p2kPa; if (dp < 0) dp = 0;
    var x = dp / p1kPa;
    if (x < FXT) return 2.73 * Cv * (1 - x / (3 * FXT)) * Math.sqrt(dp * rho); // докритический
    return (2 / 3) * 2.73 * Cv * Math.sqrt(FXT * p1kPa * rho);                 // запертый поток
  }
  function steamDensity(Pabs, Tk) { return 1 / steamState(Pabs, Tk).V; }

  /*
   * 11210 — Расход пара через клапан по Cv.
   * Вход: stmPrimPress(МПа абс), stmSecondPress(МПа абс), cvValue(Cv US), stmTemp(К|null). Выход: stmFlow(кг/ч).
   */
  CALC['11210'] = function (inp) {
    var rho = steamDensity(inp.stmPrimPress, inp.stmTemp);
    return { stmFlow: valveSteamFlow(inp.cvValue, inp.stmPrimPress * 1000, inp.stmSecondPress * 1000, rho) };
  };

  /*
   * 11220 — Пропускная способность Cv по расходу пара (обратная 11210; расход линеен по Cv).
   * Вход: stmPrimPress, stmSecondPress, stmFlow(кг/ч), stmTemp. Выход: cvValue(Cv US).
   */
  CALC['11220'] = function (inp) {
    var rho = steamDensity(inp.stmPrimPress, inp.stmTemp);
    var per = valveSteamFlow(1, inp.stmPrimPress * 1000, inp.stmSecondPress * 1000, rho);
    return { cvValue: per > 0 ? inp.stmFlow / per : NaN };
  };

  /*
   * 11230 — Расход пара через сопло/орифис. Эквивалент Cv = C·(do/4.654)², do в мм.
   * Вход: stmPrimPress, stmSecondPress, orificeDiam(м), dischargeCoeff(C), stmTemp. Выход: stmFlow(кг/ч).
   */
  CALC['11230'] = function (inp) {
    var rho = steamDensity(inp.stmPrimPress, inp.stmTemp);
    var doMm = inp.orificeDiam * 1000;
    var C = (inp.dischargeCoeff != null && !isNaN(inp.dischargeCoeff)) ? inp.dischargeCoeff : 0.70; // дефолт TLV
    var CvEq = C * Math.pow(doMm / 4.654, 2);
    return { stmFlow: valveSteamFlow(CvEq, inp.stmPrimPress * 1000, inp.stmSecondPress * 1000, rho) };
  };

  // ----- Расход конденсата -----
  // ΔH — теплота, отдаваемая паром конденсату (кДж/кг): энтальпия пара минус насыщенной воды при Ps.
  function enthDiff(Pabs, Tk) {
    var S = steam(), Ts = S.Tsat(Pabs), hf = S.satLiquid(Pabs).h;
    var hg = (Tk && Tk > Ts + 0.1) ? S.superheated(Pabs, Tk).h : S.satVapor(Pabs).h;
    return hg - hf;
  }

  /*
   * 11330 — Расход конденсата при непрерывном нагреве жидкости.
   * Вход: gravity(SG), specHeat(кДж/кг·К), lqdFlow(м³/ч), lqdInTemp(К), lqdOutTemp(К), stmPress(МПа), stmTemp(К).
   * Выход: condLoad(кг/ч).
   */
  CALC['11330'] = function (inp) {
    var dH = enthDiff(inp.stmPress, inp.stmTemp);
    return { condLoad: inp.specHeat * inp.gravity * inp.lqdFlow * (inp.lqdOutTemp - inp.lqdInTemp) / dH * 1000 };
  };

  /*
   * 11331 — Конденсат при периодическом нагреве жидкости (фиксированный объём за время).
   * Вход: ..., lqdAmount(м³), heatTime(ч). Выход: totalAmount(кг), aveAmount(кг/ч).
   */
  CALC['11331'] = function (inp) {
    var dH = enthDiff(inp.stmPress, inp.stmTemp);
    var total = inp.specHeat * inp.gravity * inp.lqdAmount * (inp.lqdOutTemp - inp.lqdInTemp) / dH * 1000;
    return { totalAmount: total, aveAmount: inp.heatTime > 0 ? total / inp.heatTime : NaN };
  };

  /*
   * 11340 — Расход конденсата при нагреве воздуха (давление атмосферное).
   * ca·γa — теплоёмкость·плотность воздуха (откалибровано по TLV). Qa в м³/ч (после конверсии из м³/мин).
   * Вход: stmPress, stmTemp, airFlow(м³/ч), airInTemp(К), airOutTemp(К). Выход: condLoad(кг/ч).
   */
  var AIR_CA_GAMMA = 1.209; // ca·γa, кДж/(м³·К) — калибровка по TLV (ca≈1.005, γa≈1.203 при 20°C)
  CALC['11340'] = function (inp) {
    var dH = enthDiff(inp.stmPress, inp.stmTemp);
    return { condLoad: AIR_CA_GAMMA * inp.airFlow * (inp.airOutTemp - inp.airInTemp) / dH };
  };

  /*
   * 12310 — Образование выпара (flash steam) при дросселировании конденсата.
   * Вход: condPress(МПа абс), condFlow(кг/ч), recoveryPress(МПа абс). Выход: flashRatio(%), flashFlow(кг/ч).
   */
  CALC['12310'] = function (inp) {
    var S = steam();
    var hw = S.satLiquid(inp.condPress).h;       // энтальпия насыщ. воды при давлении конденсата
    var hc = S.satLiquid(inp.recoveryPress).h;   // при давлении вторичного пара
    var hfg = S.latentHeat(inp.recoveryPress);
    var Rfs = (hw - hc) / hfg * 100;
    return { flashRatio: Rfs, flashFlow: Rfs / 100 * inp.condFlow };
  };

  /*
   * 11510 — Свойства насыщенного пара по давлению. Вход: stmPress(МПа абс).
   * Выход (СИ): satTemp(К), latentHeat(кДж/кг), satVapEnth(кДж/кг), satWtrEnth(кДж/кг),
   *             satVapVol(м³/кг), satWtrVol(м³/кг).
   */
  CALC['11510'] = function (inp) {
    var S = steam(), P = inp.stmPress;
    return {
      satTemp: S.Tsat(P), latentHeat: S.latentHeat(P),
      satVapEnth: S.satVapor(P).h, satWtrEnth: S.satLiquid(P).h,
      satVapVol: S.satVapor(P).v, satWtrVol: S.satLiquid(P).v
    };
  };

  /*
   * 11520 — Свойства насыщенного пара по температуре. Вход: stmTemp(К).
   * Выход: stmPress(МПа абс), latentHeat, satVapEnth, satWtrEnth, satVapVol, satWtrVol.
   */
  CALC['11520'] = function (inp) {
    var S = steam(), P = S.Psat(inp.stmTemp);
    return {
      stmPress: P, latentHeat: S.latentHeat(P),
      satVapEnth: S.satVapor(P).h, satWtrEnth: S.satLiquid(P).h,
      satVapVol: S.satVapor(P).v, satWtrVol: S.satLiquid(P).v
    };
  };

  /*
   * 11530 — Свойства перегретого пара. Вход: stmPress(МПа абс), stmTemp(К).
   * Выход: superEnth(кДж/кг), superVol(м³/кг), superCp(кДж/кг·К), superVisc(мПа·с).
   */
  CALC['11530'] = function (inp) {
    var S = steam(), st = S.superheated(inp.stmPress, inp.stmTemp);
    return {
      superEnth: st.h, superVol: st.v, superCp: S.cpSuperheated(inp.stmPress, inp.stmTemp),
      superVisc: S.viscosity(1 / st.v, inp.stmTemp) * 1000 // Па·с -> мПа·с
    };
  };

  // ----- Теплопотери через изоляцию (11320) -----
  // Коэффициент теплоотдачи с поверхности α(W/м²·К) от скорости ветра (калибровка по TLV).
  function alphaSurface(v) { return 13.06 + 5.954 * Math.pow(v < 0 ? 0 : v, 0.6); }
  // Теплопроводность изоляции λ(W/м·К) = λ0 + k·Tmean(°C). Калибровка по TLV (значения JIS).
  // Индекс = value селекта изоляции: 0 минвата Rockwool, 1 стекловата, 2 силикат кальция, 3 перлит.
  var INS_LAMBDA = [
    { l0: 0.03541, k: 1.325e-4 }, // Rockwool
    { l0: 0.02854, k: 1.846e-4 }, // стекловата
    { l0: 0.04085, k: 1.217e-4 }, // силикат кальция
    { l0: 0.06313, k: 1.227e-4 }  // перлит
  ];

  /*
   * 11320 — Теплопотери через изолированную трубу (насыщенный пар).
   * Вход: pipeOutDiam(d1,м), insType(idx), stmPress(МПа абс), windVelo(м/с),
   *       insThick(L,м), pipeLen(l,м), ambTemp(К). Выход: condLoad(кг/ч), radiantHeat(Вт, всего).
   */
  CALC['11320'] = function (inp) {
    var S = steam();
    var Ts = S.Tsat(inp.stmPress) - 273.15;          // °C
    var Tam = inp.ambTemp - 273.15;                   // °C
    var dH = S.latentHeat(inp.stmPress);
    var d1 = inp.pipeOutDiam, L = inp.insThick, D = d1 + 2 * L;
    var lnR = Math.log(D / d1);
    var alpha = alphaSurface(inp.windVelo);
    var ins = INS_LAMBDA[inp.insType] || INS_LAMBDA[0];
    var Tmean = Ts, Qr = 0;
    for (var i = 0; i < 12; i++) {                    // итерация λ↔Tmean
      var lam = ins.l0 + ins.k * Tmean;
      Qr = 2 * Math.PI * (Ts - Tam) / (lnR / lam + 2 / (D * alpha)); // Вт/м
      var Tsurf = Tam + Qr / (Math.PI * D * alpha);
      Tmean = (Ts + Tsurf) / 2;
    }
    var mc = 3.6 * Qr / dH * inp.pipeLen;             // кг/ч
    return { condLoad: mc, radiantHeat: Qr * inp.pipeLen }; // тепло — всего (Вт)
  };

  /*
   * 11310 — Расход конденсата на прогрев трубопровода при запуске (насыщенный пар).
   * mh = cp·Wp·l·(Ts-Tam)/ΔH  (теплоёмкость металла трубы),
   * mr — лучистые потери за время прогрева tSU при средней температуре прогрева (Ts+100)/2.
   * Вход: pipeOutDiam(d1,м), pipeInDiam(м), insType(idx), stmPress(МПа абс), stmTemp(К|null),
   *       windVelo(м/с), insThick(L,м), pipeLen(l,м), ambTemp(К), startTime(ч). Калибровано по TLV.
   * Выход: condHeatPipe(mh,кг), condRadiant(mr,кг), condTotal(mc,кг).
   */
  var CP_STEEL = 0.51, RHO_STEEL = 7850; // кДж/кг·К, кг/м³ (калибровка по TLV)
  CALC['11310'] = function (inp) {
    var S = steam();
    var Ts = S.Tsat(inp.stmPress) - 273.15, Tam = inp.ambTemp - 273.15;
    var dH = enthDiff(inp.stmPress, inp.stmTemp);
    var d1 = inp.pipeOutDiam, ID = inp.pipeInDiam, L = inp.insThick, D = d1 + 2 * L;
    // Конденсат на прогрев металла трубы
    var Wp = Math.PI / 4 * (d1 * d1 - ID * ID) * RHO_STEEL; // кг/м
    var mh = CP_STEEL * Wp * inp.pipeLen * (Ts - Tam) / dH;
    // Конденсат от лучистых потерь за время прогрева (λ при средней темп. прогрева)
    var Tw = (Ts + 100) / 2, alpha = alphaSurface(inp.windVelo);
    var ins = INS_LAMBDA[inp.insType] || INS_LAMBDA[0];
    var lnR = Math.log(D / d1), Tmean = Tw, Qrw = 0;
    for (var i = 0; i < 12; i++) {
      var lam = ins.l0 + ins.k * Tmean;
      Qrw = 2 * Math.PI * (Tw - Tam) / (lnR / lam + 2 / (D * alpha));
      Tmean = (Tw + (Tam + Qrw / (Math.PI * D * alpha))) / 2;
    }
    var mr = 3.6 * Qrw * inp.pipeLen * inp.startTime / dH; // startTime в часах
    return { condHeatPipe: mh, condRadiant: mr, condTotal: mh + mr };
  };

  /*
   * 11130 — Подбор размера трубы по скорости (упрощённый: без фитингов).
   * Вход: pipeGrade, stmPress, stmTemp, stmFlow, upperVelo(м/с), pipeLen, pipeRough. Выход: pipeSize, pipeInDiam, stmVelo, pressLoss.
   */
  CALC['11130'] = function (inp) {
    var S = steam(), PIPES = pipes();
    var st = steamState(inp.stmPress, inp.stmTemp), V = st.V, eta = S.viscosity(1 / V, st.T);
    var eps = inp.pipeRough != null ? inp.pipeRough : 0.05e-3;
    var list = PIPES[inp.pipeGrade] || PIPES[7], chosen = null;
    for (var i = 0; i < list.length; i++) {
      var d = list[i].id / 1000;
      var r = velAndLoss(d, inp.stmFlow, V, eta, inp.pipeLen, {}, eps);
      if (r.v <= inp.upperVelo) { chosen = { pipe: list[i], d: d, r: r }; break; }
    }
    var exceeded = false;
    if (!chosen) { var last = list[list.length - 1], dd = last.id / 1000; chosen = { pipe: last, d: dd, r: velAndLoss(dd, inp.stmFlow, V, eta, inp.pipeLen, {}, eps) }; exceeded = true; }
    return { pipeSize: formatSize(inp.pipeGrade, chosen.pipe), pipeInDiam: chosen.d, stmVelo: chosen.r.v, pressLoss: chosen.r.dp, exceeded: exceeded };
  };

  /*
   * 11350 / 11360 — Точка подтопления (stall point) для теплообменника.
   * S = (Tb − Tm)/(Ts − Tm)·100, где Tm=(T1+T2)/2 — средняя темп. среды, Tb — темп. насыщения
   * при противодавлении. Вход: lqdInTemp/airInTemp(T1,К), lqdOutTemp/airOutTemp(T2,К),
   * stmPress(МПа), stmTemp(К|null), backPress(МПа), oversur(%). Выход: stallPoint(%), stallPointOs(%).
   */
  function stallPoint(inp) {
    var S = steam();
    var Ts = (inp.stmTemp && inp.stmTemp > S.Tsat(inp.stmPress) ? inp.stmTemp : S.Tsat(inp.stmPress)) - 273.15;
    var Tb = S.Tsat(inp.backPress) - 273.15;
    var T1 = inp.t1 - 273.15, T2 = inp.t2 - 273.15, Tm = (T1 + T2) / 2;
    var Sp = (Tb - Tm) / (Ts - Tm) * 100;
    var os = inp.oversur || 0;
    return { stallPoint: Sp, stallPointOs: Sp * (1 + os / 100) }; // Os — с запасом поверхности (предв., калибровать)
  }
  CALC['11350'] = function (inp) { return stallPoint({ t1: inp.lqdInTemp, t2: inp.lqdOutTemp, stmPress: inp.stmPress, stmTemp: inp.stmTemp, backPress: inp.backPress, oversur: inp.oversur }); };
  CALC['11360'] = function (inp) { return stallPoint({ t1: inp.airInTemp, t2: inp.airOutTemp, stmPress: inp.stmPress, stmTemp: inp.stmTemp, backPress: inp.backPress, oversur: inp.oversur }); };

  // ===== ВОДА: клапаны и сопла (13200/13300/13400) =====
  // Несжимаемый поток (IEC 60534). Qw(м³/ч)=0.0865·Cv·√(Δp/SG), p в кПа.
  // Кавитация при Δp ≥ FL²·(p1−FF·Pv): Qw=0.0865·Cv·FL·√((p1−FF·Pv)/SG).
  var WV_FL = 0.9, WATER_PC_KPA = 22064;
  function waterValveFlow(Cv, p1k, p2k, SG, PvK) {
    var FF = 0.96 - 0.28 * Math.sqrt(PvK / WATER_PC_KPA);
    var dpCh = WV_FL * WV_FL * (p1k - FF * PvK), dp = p1k - p2k;
    if (dp < dpCh) return 0.0865 * Cv * Math.sqrt(dp / SG);
    return 0.0865 * Cv * WV_FL * Math.sqrt((p1k - FF * PvK) / SG);
  }
  function waterSG_Pv(Pabs, Tk) {
    var S = steam();
    return { SG: (1 / S.region1(Pabs, Tk).v) / 1000, Pv: S.Psat(Tk) * 1000 }; // Pv в кПа
  }
  // 13200 — расход воды через клапан по Cv.
  CALC['13200'] = function (inp) {
    var w = waterSG_Pv(inp.wtrPrimPress, inp.wtrTemp);
    return { wtrFlowRate: waterValveFlow(inp.cvValue, inp.wtrPrimPress * 1000, inp.wtrSecondPress * 1000, w.SG, w.Pv) };
  };
  // 13300 — Cv по расходу воды (обратная 13200, линейна по Cv).
  CALC['13300'] = function (inp) {
    var w = waterSG_Pv(inp.wtrPrimPress, inp.wtrTemp);
    var per = waterValveFlow(1, inp.wtrPrimPress * 1000, inp.wtrSecondPress * 1000, w.SG, w.Pv);
    return { cvValue: per > 0 ? inp.wtrFlowRate / per : NaN };
  };
  // 13400 — расход воды через сопло/орифис. Cv = C·(do/4.654)², do в мм.
  CALC['13400'] = function (inp) {
    var w = waterSG_Pv(inp.wtrPrimPress, inp.wtrTemp);
    var C = (inp.dischargeCoeff != null && !isNaN(inp.dischargeCoeff)) ? inp.dischargeCoeff : 0.70;
    var CvEq = C * Math.pow(inp.orificeDiam * 1000 / 4.654, 2);
    return { wtrFlowRate: waterValveFlow(CvEq, inp.wtrPrimPress * 1000, inp.wtrSecondPress * 1000, w.SG, w.Pv) };
  };

  // ===== ВОДА: гидравлика трубопроводов (13110–13150) =====
  // Температура воды по умолчанию (нет ввода на этих страницах) — калибровать по TLV.
  var WATER_T = 293.15; // 20 °C
  function waterProps(Pabs) { var V = waterV(Pabs, WATER_T); return { V: V, eta: waterVisc(WATER_T) }; }

  // 13110 — подбор трубы по допустимым потерям (вода). Qw в м³/ч, pw в МПа абс.
  CALC['13110'] = function (inp) {
    var PIPES = pipes(), wp = waterProps(inp.wtrPress), eps = inp.pipeRough != null ? inp.pipeRough : 0.05e-3;
    var Qs = inp.wtrFlow / 3600, list = PIPES[inp.pipeGrade] || PIPES[7], chosen = null;
    for (var i = 0; i < list.length; i++) {
      var d = list[i].id / 1000, v = Qs / pipeArea(d);
      var r = hydraulics(d, v, wp.V, wp.eta, inp.pipeLen, inp.fittings, eps);
      if (r.dp <= inp.allowPressLoss) { chosen = { pipe: list[i], d: d, r: r }; break; }
    }
    var exceeded = false;
    if (!chosen) { var last = list[list.length - 1], dd = last.id / 1000, vv = Qs / pipeArea(dd); chosen = { pipe: last, d: dd, r: hydraulics(dd, vv, wp.V, wp.eta, inp.pipeLen, inp.fittings, eps) }; exceeded = true; }
    return { pipeSize: formatSize(inp.pipeGrade, chosen.pipe), pipeInDiam: chosen.d, wtrVelo: chosen.r.v, pressLoss: chosen.r.dp, equivLen: chosen.r.leq, exceeded: exceeded };
  };

  // 13120 — подбор трубы по скорости (вода).
  CALC['13120'] = function (inp) {
    var PIPES = pipes(), wp = waterProps(inp.wtrPress || 0.101325), eps = inp.pipeRough != null ? inp.pipeRough : 0.05e-3;
    var Qs = inp.wtrFlow / 3600, list = PIPES[inp.pipeGrade] || PIPES[7], chosen = null;
    for (var i = 0; i < list.length; i++) {
      var d = list[i].id / 1000, v = Qs / pipeArea(d);
      if (v <= inp.upperVelo) { chosen = { pipe: list[i], d: d, r: hydraulics(d, v, wp.V, wp.eta, inp.pipeLen, inp.fittings, eps) }; break; }
    }
    var exceeded = false;
    if (!chosen) { var last = list[list.length - 1], dd = last.id / 1000, vv = Qs / pipeArea(dd); chosen = { pipe: last, d: dd, r: hydraulics(dd, vv, wp.V, wp.eta, inp.pipeLen, inp.fittings, eps) }; exceeded = true; }
    return { pipeSize: formatSize(inp.pipeGrade, chosen.pipe), pipeInDiam: chosen.d, wtrVelo: chosen.r.v, pressLoss: chosen.r.dp, equivLen: chosen.r.leq, exceeded: exceeded };
  };

  // 13130 — потери давления и скорость в заданной трубе (вода).
  CALC['13130'] = function (inp) {
    var wp = waterProps(inp.wtrPress || 0.101325), eps = inp.pipeRough != null ? inp.pipeRough : 0.05e-3;
    var v = inp.wtrFlow / 3600 / pipeArea(inp.pipeInDiam);
    var r = hydraulics(inp.pipeInDiam, v, wp.V, wp.eta, inp.pipeLen, inp.fittings, eps);
    return { wtrVelo: r.v, pressLoss: r.dp, equivLen: r.leq };
  };

  // 13140 — скорость воды в трубе. 13150 — расход воды по скорости.
  CALC['13140'] = function (inp) { return { wtrVelo: inp.wtrFlow / 3600 / pipeArea(inp.pipeInDiam) }; };
  CALC['13150'] = function (inp) { return { wtrFlowRate: inp.wtrVelo * pipeArea(inp.pipeInDiam) * 3600 }; };

  // ===== ВОЗДУХ / ГАЗ: гидравлика (14110–14160) =====
  // Состояние воздуха: V(м³/кг), eta(Па·с). Pabs в МПа.
  function airState(Pabs, Tk) { var rho = airRho(Pabs * 1e6, Tk); return { V: 1 / rho, eta: airVisc(Tk) }; }
  // Приведённый (нормальный) объёмный расход из фактического: Qn = Qa·(Pabs/0.101325)·(273.15/T).
  function normalFlow(Qactual, Pabs, Tk) { return Qactual * (Pabs / 0.101325) * (273.15 / Tk); }

  function airSizeBy(inp, byVelo) {
    var PIPES = pipes(), st = airState(inp.airPress, inp.airTemp);
    var eps = inp.pipeRough != null ? inp.pipeRough : 0.05e-3;
    var Qs = inp.airFlow / 3600, list = PIPES[inp.pipeGrade] || PIPES[7], chosen = null;
    for (var i = 0; i < list.length; i++) {
      var d = list[i].id / 1000, v = Qs / pipeArea(d);
      var r = hydraulics(d, v, st.V, st.eta, inp.pipeLen, inp.fittings, eps);
      var ok = byVelo ? (v <= inp.upperVelo) : (r.dp <= inp.allowPressLoss);
      if (ok) { chosen = { pipe: list[i], d: d, r: r }; break; }
    }
    var exceeded = false;
    if (!chosen) { var last = list[list.length - 1], dd = last.id / 1000, vv = Qs / pipeArea(dd); chosen = { pipe: last, d: dd, r: hydraulics(dd, vv, st.V, st.eta, inp.pipeLen, inp.fittings, eps) }; exceeded = true; }
    return { pipeSize: formatSize(inp.pipeGrade, chosen.pipe), pipeInDiam: chosen.d, airVelo: chosen.r.v, pressLoss: chosen.r.dp, equivLen: chosen.r.leq, exceeded: exceeded };
  }
  CALC['14110'] = function (inp) { return airSizeBy(inp, false); };
  CALC['14120'] = function (inp) { return airSizeBy(inp, true); };
  CALC['14130'] = function (inp) {
    var st = airState(inp.airPress, inp.airTemp), eps = inp.pipeRough != null ? inp.pipeRough : 0.05e-3;
    var v = inp.airFlow / 3600 / pipeArea(inp.pipeInDiam);
    var r = hydraulics(inp.pipeInDiam, v, st.V, st.eta, inp.pipeLen, inp.fittings, eps);
    return { airVelo: r.v, pressLoss: r.dp, equivLen: r.leq };
  };
  // 14140 — газ: ρ из мол. массы, вязкость задаётся пользователем (мПа·с).
  CALC['14140'] = function (inp) {
    var V = 1 / gasRho(inp.gasPress * 1e6, inp.molecular, inp.gasTemp), eta = inp.gasVisc / 1000; // мПа·с->Па·с
    var eps = inp.pipeRough != null ? inp.pipeRough : 0.05e-3;
    var v = inp.gasFlow / 3600 / pipeArea(inp.pipeInDiam);
    var r = hydraulics(inp.pipeInDiam, v, V, eta, inp.pipeLen, inp.fittings, eps);
    return { gasVelo: r.v, pressLoss: r.dp, equivLen: r.leq };
  };
  // 14150 — скорость воздуха. 14160 — расход воздуха (фактический + приведённый).
  CALC['14150'] = function (inp) { return { airVelo: inp.airFlow / 3600 / pipeArea(inp.pipeInDiam) }; };
  CALC['14160'] = function (inp) {
    var Qa = inp.airVelo * pipeArea(inp.pipeInDiam) * 3600; // м³/ч факт.
    return { airFlowRate: Qa, airFlowRateN: normalFlow(Qa, inp.airPress, inp.airTemp) };
  };

  // ===== ВОЗДУХ: клапаны и сопла (14200/14300/14400) =====
  // Сжимаемый поток, константа 4.17 (vs 2.73 для пара). Qa в Nм³/ч. p в кПа абс.
  var AIR_FXT = 0.72; // Fγ·xT для воздуха (Fγ=1.0, xT=0.72) — сверено с TLV
  function airValveFlowN(Cv, p1k, p2k, Tk) {
    var dp = p1k - p2k; if (dp < 0) dp = 0;
    var x = dp / p1k;
    // формула TLV даёт Nм³/мин (с /60); SI=Nм³/ч => ·60, факторы сокращаются
    if (x < AIR_FXT) return 4.17 * Cv * p1k * (1 - x / (3 * AIR_FXT)) * Math.sqrt(x / Tk);
    return (2 / 3) * 4.17 * Cv * p1k * Math.sqrt(AIR_FXT / Tk);
  }
  CALC['14200'] = function (inp) {
    return { airFlowRateN: airValveFlowN(inp.cvValue, inp.airPrimPress * 1000, inp.airSecondPress * 1000, inp.airTemp) };
  };
  CALC['14300'] = function (inp) {
    var per = airValveFlowN(1, inp.airPrimPress * 1000, inp.airSecondPress * 1000, inp.airTemp);
    return { cvValue: per > 0 ? inp.airFlowRateN / per : NaN };
  };
  CALC['14400'] = function (inp) {
    var C = (inp.dischargeCoeff != null && !isNaN(inp.dischargeCoeff)) ? inp.dischargeCoeff : 0.70;
    var CvEq = C * Math.pow(inp.orificeDiam * 1000 / 4.654, 2);
    return { airFlowRateN: airValveFlowN(CvEq, inp.airPrimPress * 1000, inp.airSecondPress * 1000, inp.airTemp) };
  };

  // ===== КОТЁЛ, СТОИМОСТЬ, СУХОСТЬ, ПАРОВОЗДУШНАЯ СМЕСЬ (114xx) =====
  // Энтальпия питательной/сырой воды (кДж/кг) при T(К): насыщенная вода ~ region1 при низком p.
  function waterEnth(Tk) { return steam().region1(0.101325, Tk).h; }

  // 11410 — КПД котла и коэффициент нагрузки.
  CALC['11410'] = function (inp) {
    var S = steam(), P = inp.boilerPress, mb = inp.boilerBlow || 0;
    var hw = S.satLiquid(P).h, dH = S.latentHeat(P), hfw = waterEnth(inp.feedWtrTemp);
    var eff = (inp.feedWtrRate - mb) * (hw + 0.98 * dH - hfw) / (inp.fuelConsumption * inp.fuelCalVal) * 100;
    var lf = (inp.feedWtrRate - mb) / inp.boilerCapa * 100;
    return { boilerEff: eff, loadFactor: lf };
  };
  // 11420 — стоимость единицы энергии. Ce=Cf/(Hf·η/100). Cf $/т, Hf кДж/кг → Ce $/МДж.
  CALC['11420'] = function (inp) {
    return { energyUnitCost: inp.fuelUnitCost / (inp.fuelCalVal * inp.boilerEff / 100) };
  };
  // 11430 — стоимость пара. Cs=(hs−hfw)·Ce. $/т.
  CALC['11430'] = function (inp) {
    var st = steamState(inp.stmPress, inp.stmTemp);
    var hs = inp.stmTemp && inp.stmTemp > steam().Tsat(inp.stmPress) ? steam().superheated(inp.stmPress, inp.stmTemp).h : steam().satVapor(inp.stmPress).h;
    var hfw = waterEnth(inp.feedWtrTemp);
    return { stmCost: (hs - hfw) * inp.energyUnitCost };
  };

  // Сухость/перегрев пара после дросселирования с p1(сухость X1%) до p2.
  function drynessAfter(P1, X1, P2) {
    var S = steam();
    var h1 = S.satVapor(P1).h - (1 - X1 / 100) * S.latentHeat(P1); // энтальпия влажного пара при p1
    var hg2 = S.satVapor(P2).h, Ts2 = S.Tsat(P2);
    if (h1 < hg2) { // остался влажным
      return { secDryness: (1 - (hg2 - h1) / S.latentHeat(P2)) * 100, degreeOfSuper: 0, satTemp: Ts2 };
    }
    // перегрет: ΔT = (h1 − hg2)/cp (cp при насыщении на p2) — как в TLV
    return { secDryness: 100, degreeOfSuper: (h1 - hg2) / S.cpSuperheated(P2, Ts2), satTemp: Ts2 };
  }
  // 11440 — улучшение сухости после редуцирования.
  CALC['11440'] = function (inp) {
    var r = drynessAfter(inp.stmPrimPress, inp.estPrimStmDry, inp.stmSecondPress);
    return { secDryness: r.secDryness, degreeOfSuper: r.degreeOfSuper, satTemp: r.satTemp };
  };
  // 11450 — сухость после редуцирования и сепаратора.
  CALC['11450'] = function (inp) {
    var ms = inp.stmFlow, mc = inp.sepaCond, eta = inp.separateEff;
    var X1 = (1 - mc / (ms * eta / 100)) * 100;            // оценочная первичная сухость
    var Xp1 = (ms - mc / (eta / 100)) / (ms - mc) * 100;   // сухость после сепаратора
    var r = drynessAfter(inp.stmPrimPress, Xp1, inp.stmSecondPress);
    return { estPrimStmDry: X1, secDryness: r.secDryness, degreeOfSuper: r.degreeOfSuper, satTemp: r.satTemp };
  };

  // 11460 — паровоздушная смесь: по доле воздуха → падение температуры.
  CALC['11460'] = function (inp) {
    var S = steam(), p = inp.stmPress, ps = p * (1 - inp.airVolume / 100);
    var Tm = S.Tsat(ps), Tsat = S.Tsat(p);
    return { tempOfMix: Tm, partPress: ps, satTemp: Tsat, tempDrop: Tsat - Tm };
  };
  // 11461 — паровоздушная смесь: по температуре смеси → доля воздуха.
  CALC['11461'] = function (inp) {
    var S = steam(), p = inp.stmPress, ps = S.Psat(inp.tempOfMix);
    var Tsat = S.Tsat(p);
    return { airVolume: (1 - ps / p) * 100, partPress: ps, satTemp: Tsat, tempDrop: Tsat - inp.tempOfMix };
  };

  // ===== КОНДЕНСАТОПРОВОДЫ (12210/12220/12221/12230) =====
  // Двухфазный удельный объём конденсата после вскипания с Cp до Rp.
  function condTwoPhase(CpAbs, RpAbs) {
    var S = steam();
    var Rfs = (S.satLiquid(CpAbs).h - S.satLiquid(RpAbs).h) / S.latentHeat(RpAbs);
    if (Rfs < 0) Rfs = 0;
    var vf = S.satLiquid(RpAbs).v, vg = S.satVapor(RpAbs).v;
    var Vtemp = vf + Rfs * (vg - vf);
    var eta = waterVisc(S.Tsat(RpAbs)); // эфф. вязкость двухфазного потока ≈ насыщ. вода при Rp
    return { V: Vtemp, eta: eta, Rfs: Rfs };
  }
  // 12220 — подбор конденсатопровода по допустимым потерям давления.
  CALC['12220'] = function (inp) {
    var PIPES = pipes(), tp = condTwoPhase(inp.condPress, inp.recoveryPress);
    var eps = inp.pipeRough != null ? inp.pipeRough : 0.05e-3, Qs = inp.condFlow / 3600;
    var list = PIPES[inp.pipeGrade] || PIPES[7], chosen = null;
    for (var i = 0; i < list.length; i++) {
      var d = list[i].id / 1000, v = Qs * tp.V / pipeArea(d);
      var r = hydraulics(d, v, tp.V, tp.eta, inp.pipeLen, inp.fittings, eps);
      if (r.dp <= inp.allowPressLoss) { chosen = { pipe: list[i], d: d, r: r }; break; }
    }
    var exceeded = false;
    if (!chosen) { var last = list[list.length - 1], dd = last.id / 1000, vv = Qs * tp.V / pipeArea(dd); chosen = { pipe: last, d: dd, r: hydraulics(dd, vv, tp.V, tp.eta, inp.pipeLen, inp.fittings, eps) }; exceeded = true; }
    return { pipeSize: formatSize(inp.pipeGrade, chosen.pipe), pipeInDiam: chosen.d, condVelo: chosen.r.v, pressLoss: chosen.r.dp, equivLen: chosen.r.leq, exceeded: exceeded };
  };
  // 12221 — подбор конденсатопровода по допустимой скорости.
  CALC['12221'] = function (inp) {
    var PIPES = pipes(), tp = condTwoPhase(inp.condPress, inp.recoveryPress);
    var eps = inp.pipeRough != null ? inp.pipeRough : 0.05e-3, Qs = inp.condFlow / 3600;
    var list = PIPES[inp.pipeGrade] || PIPES[7], chosen = null;
    for (var i = 0; i < list.length; i++) {
      var d = list[i].id / 1000, v = Qs * tp.V / pipeArea(d);
      if (v <= inp.upperVelo) { chosen = { pipe: list[i], d: d, r: hydraulics(d, v, tp.V, tp.eta, inp.pipeLen, inp.fittings, eps) }; break; }
    }
    var exceeded = false;
    if (!chosen) { var last = list[list.length - 1], dd = last.id / 1000, vv = Qs * tp.V / pipeArea(dd); chosen = { pipe: last, d: dd, r: hydraulics(dd, vv, tp.V, tp.eta, inp.pipeLen, inp.fittings, eps) }; exceeded = true; }
    return { pipeSize: formatSize(inp.pipeGrade, chosen.pipe), pipeInDiam: chosen.d, condVelo: chosen.r.v, pressLoss: chosen.r.dp, equivLen: chosen.r.leq, exceeded: exceeded };
  };
  // 12210/12230 — упрощённый подбор по скорости (конденсат как жидкость, без вскипания).
  function condSimpleSize(inp) {
    var PIPES = pipes(), V = waterV(0.101325 + (inp.condPress || 0), WATER_T), Qs = inp.condFlow / 3600;
    var list = PIPES[inp.pipeGrade] || PIPES[7], chosen = null;
    for (var i = 0; i < list.length; i++) { var d = list[i].id / 1000, v = Qs / pipeArea(d); if (v <= inp.upperVelo) { chosen = { pipe: list[i], d: d, v: v }; break; } }
    if (!chosen) { var last = list[list.length - 1], dd = last.id / 1000; chosen = { pipe: last, d: dd, v: Qs / pipeArea(dd) }; }
    return { pipeSize: formatSize(inp.pipeGrade, chosen.pipe), pipeInDiam: chosen.d, condVelo: chosen.v };
  }
  CALC['12210'] = condSimpleSize;
  CALC['12230'] = condSimpleSize;

  // ===== РЕКУПЕРАЦИЯ ТЕПЛА КОНДЕНСАТА (12110–12140) =====
  // Общие денежные выходы по рекуперированному теплу Hr (Вт). Калибровано по TLV.
  //   recoverValue (×1000 $/год) = 3.6·Hr·h·Ce / 1e6   (Ce в $/МДж)
  //   annFuelSave (кг/год) = 3.6·Hr·h / (Hf·η/100)
  //   fuelConserv (%) = Hr·0.86 / (hs/4.186 − Tfw) / mfw · 100   (hs — энтальпия пара при давл. котла)
  function recoveryEcon(Hr, inp) {
    var S = steam();
    var h = inp.annual, Ce = inp.energyUnitCost, Hf = inp.fuelCalVal, eta = inp.boilerEff;
    var Tfw = inp.feedWtrTemp - 273.15, mfw = inp.feedWtrRate, hs = S.satVapor(inp.stmPress).h;
    return {
      heatRecover: Hr,
      recoverValue: 3.6 * Hr * h * Ce / 1e6,
      annFuelSave: 3.6 * Hr * h / (Hf * eta / 100),
      fuelConserv: Hr * 0.86 / (hs / 4.186 - Tfw) / mfw * 100
    };
  }

  // 12120 — закрытая система возврата конденсата. Tc=Tsat(давл. конденсата).
  CALC['12120'] = function (inp) {
    var Tc = steam().Tsat(inp.condPress) - 273.15, Tfw = inp.feedWtrTemp - 273.15;
    var Hr = (Tc - Tfw) * inp.condFlow / 0.86;
    return recoveryEcon(Hr, inp);
  };

  // 12110 — открытая система (смешение конденсата с питательной водой в баке).
  CALC['12110'] = function (inp) {
    var Tc = steam().Tsat(inp.condPress) - 273.15, Tfw = inp.feedWtrTemp - 273.15;
    var Tfwmax = inp.allowTemp - 273.15, mc = inp.condFlow, mfw = inp.feedWtrRate;
    var Tm = (Tc * mc + (mfw - mc) * Tfw) / mfw;
    var Tfw2, Hr, Hu;
    if (Tm < Tfwmax) { Tfw2 = Tm; Hr = (Tm - Tfw) * mfw / 0.86; Hu = 0; }
    else { Tfw2 = Tfwmax; Hr = (Tfwmax - Tfw) * mfw / 0.86; Hu = (Tm - Tfwmax) * mfw / 0.86; }
    var e = recoveryEcon(Hr, inp);
    e.unrecoverHeat = Hu; e.feedWtrTemp2 = Tfw2 + 273.15; // вернуть в К для вывода через temp
    return e;
  };

  // 12140 — рекуперация выпара (нагрев сырой воды паром вторичного вскипания).
  CALC['12140'] = function (inp) {
    var S = steam();
    var mfs = inp.condFlow * (S.satLiquid(inp.condPress).h - S.satLiquid(inp.flashPress).h) / S.latentHeat(inp.flashPress);
    var Trw = inp.rawWtrTemp - 273.15;
    var Hr = mfs * (S.satVapor(inp.flashPress).h / 4.186 - Trw) / 0.86;
    var e = recoveryEcon(Hr, inp);
    e.flashFlowRate = mfs;
    return e;
  };

  // 12130 — экономический анализ возврата конденсата для теплообменника.
  // Конденсат (mc) при Tsat(давл. конденсата) отдаёт сенсибельное тепло потоку
  // нагреваемой жидкости (Ql). Потолок смешения Tc, фактический выход T2 через
  // температурный КПД ηT. Тепло, переданное жидкости, пересчитывается в массу
  // греющего пара ms = Q/hfg(Ps) и далее в возвращённое (котловое) тепло
  // Hr = ms·(hg(Ps) − hf(Trw)). Калибровано по TLV (T2 точно, Hr ±0.01%).
  CALC['12130'] = function (inp) {
    var S = steam();
    var T1 = inp.lqdInTemp - 273.15;
    var Tcond = S.Tsat(inp.condPress) - 273.15;
    var Cl = inp.gravity * 1000 * inp.lqdFlow * inp.specHeat; // кДж/(ч·К)
    var Tc = T1 + inp.condFlow * 4.19 * (Tcond - T1) / Cl;    // потолок смешения
    var T2 = T1 + (Tc - T1) * inp.tempEff / 100;
    var QlHeat = Cl * (T2 - T1);                              // кДж/ч в жидкость
    var ms = QlHeat / S.latentHeat(inp.stmPress);            // кг/ч греющего пара
    var hfRw = 4.186 * (inp.rawWtrTemp - 273.15);            // энтальпия сырой воды (cp=4.186, как в TLV)
    var Hr = ms * (S.satVapor(inp.stmPress).h - hfRw) / 3.6;  // Вт
    var e = recoveryEcon(Hr, inp);
    e.lqdOutTemp = T2 + 273.15; // в К для вывода через temp
    return e;
  };

  // ===== ПСИХРОМЕТРИЯ ВЛАЖНОГО ВОЗДУХА (14500, 14600) =====
  // Полное давление 101.325 кПа (760 мм рт.ст.). ps насыщения воды — по IAPWS-IF97
  // (та же кривая, что у паровых таблиц проекта). Абсолютная влажность насыщения
  // X=0.622·ps/(P−ps); уд. объём насыщ. воздуха V=Ra·T/(P−ps), Ra=0.287055.
  // Сверено с таблицей TLV (humid-air-table) — ps/X/V совпадают в рабочем диапазоне
  // (амбиент/охлаждение ≤50°C); выше 50°C у TLV своя заниженная корреляция V.
  var PSY_P = 101.325; // кПа
  function psWater(Tc) { return steam().Psat(Tc + 273.15) * 1000; } // кПа
  function humSat(Tc) { var p = psWater(Tc); return 622 * p / (PSY_P - p); } // г/кг
  function moistVolSat(Tc) { var p = psWater(Tc); return 0.287055 * (Tc + 273.15) / (PSY_P - p); } // м³/кг

  // 14600 — таблица насыщения влажного воздуха по температуре.
  // Выходы: абс. влажность (г/кг), парц. давление пара (МПа абс), уд. объём (м³/кг).
  CALC['14600'] = function (inp) {
    var T = inp.airTemp - 273.15;
    return { humidity: humSat(T), partPress: psWater(T) / 1000, airSpecVol: moistVolSat(T) };
  };

  // 14500 — расход конденсата при осушении сжатого воздуха.
  // Влажный воздух (отн. влажность Φ при Tam) сжимается до Pa и охлаждается до Tc;
  // выпадает конденсат. Pr — степень сжатия (абс). Калибровано по TLV.
  //   dv1=X(Tam), dv2=X(Tc) — абс. влажность насыщ.; p1=ps(Tam), p2=ps(Tc) [мм рт.ст.]
  //   Vtemp=V(Tam)·(760−p1)/(760−Φ·p1) — уд. объём фактич. влажного воздуха
  //   Xr=dv2·(760−p2)/(760·Pr−p2) — остаточная влажность после сжатия+охлаждения
  //   mc=(X1−Xr)·Qa·60/Vtemp/1000, X1=Φ·dv1
  var MMHG = 7.5006168; // кПа -> мм рт.ст.
  CALC['14500'] = function (inp) {
    var phi = inp.relative / 100;
    var Tam = inp.ambTemp - 273.15, Tc = inp.coolTemp - 273.15;
    var dv1 = humSat(Tam), dv2 = humSat(Tc);
    var p1 = psWater(Tam) * MMHG, p2 = psWater(Tc) * MMHG;
    var Pr = inp.airPress * 1000 / 101.325; // степень сжатия = абс. давление (кПа) / атм
    var Vtemp = moistVolSat(Tam) * (760 - p1) / (760 - phi * p1);
    var Xr = dv2 * (760 - p2) / (760 * Pr - p2);
    var X1 = phi * dv1;
    var mc = (X1 - Xr) * inp.airFlowN * 60 / Vtemp / 1000;
    // точка росы: ps(Tdp)=Φ·ps(Tam)
    var dewP = dewPoint(phi * psWater(Tam));
    return { condFlowLoad: mc < 0 ? 0 : mc, initMoistCont: X1, dewPoint: dewP + 273.15 };
  };

  // Точка росы [°C] по заданному парциальному давлению пара pv [кПа]:
  // обратная к ps(T) бисекция по кривой насыщения IF97.
  function dewPoint(pvKPa) {
    if (pvKPa <= 0) return -273.15;
    var lo = -50, hi = 200;
    for (var i = 0; i < 60; i++) {
      var mid = (lo + hi) / 2;
      if (psWater(mid) < pvKPa) lo = mid; else hi = mid;
    }
    return (lo + hi) / 2;
  }

  // 13500 — антиконденсатная (противоросная) изоляция трубопроводов холодной воды.
  // Толщина L, при которой температура поверхности изоляции = точке росы Tdp
  // (исключает выпадение конденсата). Неявное уравнение:
  //   (d1+2L)·ln((d1+2L)/d1) = 2λ/α·(Ti−Tdp)/(Tdp−Tam)
  // α неподвижного воздуха ≈ 7.4 Вт/м²·К (калибровка TLV); λ изоляции при
  // Tmean=(Ti+Tdp)/2. Толщина округляется до 5 мм («InsThick5»). Сверено с TLV
  // (точка росы точно; толщина совпадает с точностью до шага округления).
  var ANTISWEAT_ALPHA = 7.4;
  CALC['13500'] = function (inp) {
    var phi = inp.relative / 100;
    var Ti = inp.internalTemp - 273.15, Tam = inp.ambTemp - 273.15;
    var Tdp = dewPoint(phi * psWater(Tam));
    var d1 = inp.pipeOutDiam; // м
    var ins = INS_LAMBDA[inp.insType] || INS_LAMBDA[0];
    var lam = ins.l0 + ins.k * (Ti + Tdp) / 2;
    var rhs = 2 * lam / ANTISWEAT_ALPHA * (Ti - Tdp) / (Tdp - Tam);
    var lo = d1, hi = d1 * 60;
    for (var b = 0; b < 100; b++) { var mid = (lo + hi) / 2; if (mid * Math.log(mid / d1) < rhs) lo = mid; else hi = mid; }
    var L = ((lo + hi) / 2 - d1) / 2;
    var Lr = Math.round(L * 1000 / 5) * 5 / 1000; // округление до 5 мм
    return { insThick: Lr, dewPoint: Tdp + 273.15 };
  };

  // 11470 — экономичная толщина изоляции паропровода.
  // Оптимум выбирается перебором стандартных толщин (шаг 5 мм) по минимуму полной
  // стоимости: f(L) = площадь_изоляции(L) + drv·Qr_пог(L), где
  //   drv = Ce·A(i,m)·h·ρ — приведённая ценность теплопотерь,
  //   A(i,m) = (1−(1+i)^−m)/i — аннуитетный фактор (i=0 → A=m),
  //   ρ = 6.75e-9 (калибровка по TLV). Модель теплопотерь — как у calc-13
  //   (α=alphaSurface(v), λ изоляции при Tmean итерацией).
  // ВАЖНО (выявлено калибровкой TLV): стоимость изоляции Ci2 на ВЫБОР толщины НЕ
  // влияет (идёт только в денежный вывод, не реализуемый здесь) — драйвер чисто
  // энергетический Ce·A(i,m)·h. Сверено с TLV: толщина воспроизводится с точностью
  // до шага 5 мм (на калибровочном наборе 9/12 точно, остальные ±5 мм); для крупных
  // труб (DN150+) теплопотери могут отклоняться до ~10% (α неподвижного воздуха).
  var ECON_RHO = 6.75e-9;
  CALC['11470'] = function (inp) {
    var S = steam();
    var Ts = inp.stmTemp != null ? inp.stmTemp - 273.15 : S.Tsat(inp.stmPress) - 273.15;
    var Tam = inp.ambTemp - 273.15;
    var d1 = inp.pipeOutDiam, l = inp.pipeLen;
    var alpha = alphaSurface(inp.windVelo);
    var ins = INS_LAMBDA[inp.insType] || INS_LAMBDA[0];
    function heat(L) {
      var d2 = d1 + 2 * L, lnR = Math.log(d2 / d1), Tmean = Ts, Q = 0, Tsurf = 0;
      for (var it = 0; it < 40; it++) {
        var lam = ins.l0 + ins.k * Tmean;
        Q = 2 * Math.PI * (Ts - Tam) / (lnR / lam + 2 / (d2 * alpha));
        Tsurf = Tam + Q / (Math.PI * d2 * alpha);
        Tmean = (Ts + Tsurf) / 2;
      }
      return { Q: Q, Tsurf: Tsurf };
    }
    var i = inp.interestRate / 100;
    var Aann = i === 0 ? inp.paybackPeriod : (1 - Math.pow(1 + i, -inp.paybackPeriod)) / i;
    var drv = inp.energyUnitCost * Aann * inp.annual * ECON_RHO;
    var best = null;
    for (var mm = 5; mm <= 300; mm += 5) {
      var L = mm / 1000, d2 = d1 + 2 * L;
      var area = Math.PI / 4 * (d2 * d2 - d1 * d1);
      var hres = heat(L);
      var f = area + drv * hres.Q;
      if (!best || f < best.f) best = { f: f, mm: mm, Q: hres.Q, Tsurf: hres.Tsurf };
    }
    return { tranceCoeff: alpha, radiant: best.Q * l, insThick: best.mm / 1000, surfaceTemp: best.Tsurf + 273.15 };
  };

  // Подпись типоразмера: для DIN -> "DN80", иначе метрический размер.
  function formatSize(gradeIdx, pipe) {
    if (gradeIdx === 7) return 'DN' + parseInt(pipe.m, 10);
    return pipe.m;
  }

  if (typeof window !== 'undefined') { window.CALC = CALC; window.CALC_helpers = { colebrook: colebrook, velAndLoss: velAndLoss, steamState: steamState }; }
  if (typeof module !== 'undefined' && module.exports) module.exports = { CALC: CALC, colebrook: colebrook, velAndLoss: velAndLoss, steamState: steamState };
})();

/*
 * Таблица типоразмеров труб (165 шт), сгенерирована из formulas/tlv_app_reverse/pipes.json.
 * Индекс = value класса трубопровода в форме (0..7): JIS-SGP, JIS-STPG Sch40, JIS-STPG Sch60, JIS-STPG Sch80, ANSI Sch40, ANSI Sch80, ANSI Sch160, DIN 2448.
 * id/od — внутр./наружн. диаметр в мм. Конкатенируется в build — без import/export.
 */
(function(){
  var T={"0":[{"m":"6A","i":"NPS1/8","id":6.5,"od":10.5},{"m":"8A","i":"NPS1/4","id":9.2,"od":13.8},{"m":"10A","i":"NPS3/8","id":12.7,"od":17.3},{"m":"15A","i":"NPS1/2","id":16.1,"od":21.7},{"m":"20A","i":"NPS3/4","id":21.6,"od":27.2},{"m":"25A","i":"NPS1","id":27.6,"od":34},{"m":"32A","i":"NPS1 1/4","id":35.7,"od":42.7},{"m":"40A","i":"NPS1 1/2","id":41.6,"od":48.6},{"m":"50A","i":"NPS2","id":52.9,"od":60.5},{"m":"65A","i":"NPS2 1/2","id":67.9,"od":76.3},{"m":"80A","i":"NPS3","id":80.7,"od":89.1},{"m":"100A","i":"NPS4","id":105.3,"od":114.3},{"m":"125A","i":"NPS5","id":130.8,"od":139.8},{"m":"150A","i":"NPS6","id":155.2,"od":165.2},{"m":"200A","i":"NPS8","id":204.7,"od":216.3},{"m":"250A","i":"NPS10","id":254.2,"od":267.4},{"m":"300A","i":"NPS12","id":304.7,"od":318.5},{"m":"350A","i":"NPS14","id":339.8,"od":355.6},{"m":"400A","i":"NPS16","id":390.6,"od":406.4},{"m":"450A","i":"NPS18","id":441.4,"od":457.2},{"m":"500A","i":"NPS20","id":492.2,"od":508}],"1":[{"m":"6A","i":"NPS1/8","id":7.1,"od":10.5},{"m":"8A","i":"NPS1/4","id":9.4,"od":13.8},{"m":"10A","i":"NPS3/8","id":12.7,"od":17.3},{"m":"15A","i":"NPS1/2","id":16.1,"od":21.7},{"m":"20A","i":"NPS3/4","id":21.4,"od":27.2},{"m":"25A","i":"NPS1","id":27.2,"od":34},{"m":"32A","i":"NPS1 1/4","id":35.5,"od":42.7},{"m":"40A","i":"NPS1 1/2","id":41.2,"od":48.6},{"m":"50A","i":"NPS2","id":52.7,"od":60.5},{"m":"65A","i":"NPS2 1/2","id":65.9,"od":76.3},{"m":"80A","i":"NPS3","id":78.1,"od":89.1},{"m":"100A","i":"NPS4","id":102.3,"od":114.3},{"m":"125A","i":"NPS5","id":126.6,"od":139.8},{"m":"150A","i":"NPS6","id":151,"od":165.2},{"m":"200A","i":"NPS8","id":199.9,"od":216.3},{"m":"250A","i":"NPS10","id":248.8,"od":267.4},{"m":"300A","i":"NPS12","id":297.9,"od":318.5},{"m":"350A","i":"NPS14","id":333.4,"od":355.6},{"m":"400A","i":"NPS16","id":381,"od":406.4},{"m":"450A","i":"NPS18","id":428.6,"od":457.2},{"m":"500A","i":"NPS20","id":477.8,"od":508}],"2":[{"m":"6A","i":"NPS1/8","id":6.1,"od":10.5},{"m":"8A","i":"NPS1/4","id":9,"od":13.8},{"m":"10A","i":"NPS3/8","id":11.7,"od":17.3},{"m":"15A","i":"NPS1/2","id":15.3,"od":21.7},{"m":"20A","i":"NPS3/4","id":20.4,"od":27.2},{"m":"25A","i":"NPS1","id":26.2,"od":34},{"m":"32A","i":"NPS1 1/4","id":33.7,"od":42.7},{"m":"40A","i":"NPS1 1/2","id":39.6,"od":48.6},{"m":"50A","i":"NPS2","id":50.7,"od":60.5},{"m":"65A","i":"NPS2 1/2","id":64.3,"od":76.3},{"m":"80A","i":"NPS3","id":75.9,"od":89.1},{"m":"100A","i":"NPS4","id":100.1,"od":114.3},{"m":"125A","i":"NPS5","id":123.6,"od":139.8},{"m":"150A","i":"NPS6","id":146.6,"od":165.2},{"m":"200A","i":"NPS8","id":195.7,"od":216.3},{"m":"250A","i":"NPS10","id":242,"od":267.4},{"m":"300A","i":"NPS12","id":289.9,"od":318.5},{"m":"350A","i":"NPS14","id":325.4,"od":355.6},{"m":"400A","i":"NPS16","id":373,"od":406.4},{"m":"450A","i":"NPS18","id":419.2,"od":457.2},{"m":"500A","i":"NPS20","id":466.8,"od":508}],"3":[{"m":"6A","i":"NPS1/8","id":5.7,"od":10.5},{"m":"8A","i":"NPS1/4","id":7.8,"od":13.8},{"m":"10A","i":"NPS3/8","id":10.9,"od":17.3},{"m":"15A","i":"NPS1/2","id":14.3,"od":21.7},{"m":"20A","i":"NPS3/4","id":19.4,"od":27.2},{"m":"25A","i":"NPS1","id":25,"od":34},{"m":"32A","i":"NPS1 1/4","id":32.9,"od":42.7},{"m":"40A","i":"NPS1 1/2","id":38.4,"od":48.6},{"m":"50A","i":"NPS2","id":49.5,"od":60.5},{"m":"65A","i":"NPS2 1/2","id":62.3,"od":76.3},{"m":"80A","i":"NPS3","id":73.9,"od":89.1},{"m":"100A","i":"NPS4","id":97.1,"od":114.3},{"m":"125A","i":"NPS5","id":120.8,"od":139.8},{"m":"150A","i":"NPS6","id":143.2,"od":165.2},{"m":"200A","i":"NPS8","id":190.9,"od":216.3},{"m":"250A","i":"NPS10","id":237.2,"od":267.4},{"m":"300A","i":"NPS12","id":283.7,"od":318.5},{"m":"350A","i":"NPS14","id":317.6,"od":355.6},{"m":"400A","i":"NPS16","id":363.6,"od":406.4},{"m":"450A","i":"NPS18","id":409.6,"od":457.2},{"m":"500A","i":"NPS20","id":455.6,"od":508}],"4":[{"m":"6A","i":"NPS1/8","id":6.8326,"od":10.287},{"m":"8A","i":"NPS1/4","id":9.2456,"od":13.716},{"m":"10A","i":"NPS3/8","id":12.5222,"od":17.145},{"m":"15A","i":"NPS1/2","id":15.7988,"od":21.336},{"m":"20A","i":"NPS3/4","id":20.9296,"od":26.67},{"m":"25A","i":"NPS1","id":26.6446,"od":33.401},{"m":"32A","i":"NPS1 1/4","id":35.052,"od":42.164},{"m":"40A","i":"NPS1 1/2","id":40.894,"od":48.26},{"m":"50A","i":"NPS2","id":52.5018,"od":60.325},{"m":"65A","i":"NPS2 1/2","id":62.7126,"od":73.025},{"m":"80A","i":"NPS3","id":77.9272,"od":88.9},{"m":"100A","i":"NPS4","id":102.2604,"od":114.3},{"m":"125A","i":"NPS5","id":128.1938,"od":141.3002},{"m":"150A","i":"NPS6","id":154.051,"od":168.275},{"m":"200A","i":"NPS8","id":202.7174,"od":219.075},{"m":"250A","i":"NPS10","id":254.508,"od":273.05},{"m":"300A","i":"NPS12","id":303.2252,"od":323.85},{"m":"350A","i":"NPS14","id":333.3496,"od":355.6},{"m":"400A","i":"NPS16","id":381,"od":406.4},{"m":"450A","i":"NPS18","id":428.6504,"od":457.2},{"m":"500A","i":"NPS20","id":477.8248,"od":508}],"5":[{"m":"6A","i":"NPS1/8","id":5.461,"od":10.287},{"m":"8A","i":"NPS1/4","id":7.6708,"od":13.716},{"m":"10A","i":"NPS3/8","id":10.7442,"od":17.145},{"m":"15A","i":"NPS1/2","id":13.8684,"od":21.336},{"m":"20A","i":"NPS3/4","id":18.8468,"od":26.67},{"m":"25A","i":"NPS1","id":24.3078,"od":33.401},{"m":"32A","i":"NPS1 1/4","id":32.4612,"od":42.164},{"m":"40A","i":"NPS1 1/2","id":38.1,"od":48.26},{"m":"50A","i":"NPS2","id":49.2506,"od":60.325},{"m":"65A","i":"NPS2 1/2","id":59.0042,"od":73.025},{"m":"80A","i":"NPS3","id":73.66,"od":88.9},{"m":"100A","i":"NPS4","id":97.1804,"od":114.3},{"m":"125A","i":"NPS5","id":122.2502,"od":141.3002},{"m":"150A","i":"NPS6","id":146.3294,"od":168.275},{"m":"200A","i":"NPS8","id":193.675,"od":219.075},{"m":"250A","i":"NPS10","id":242.8748,"od":273.05},{"m":"300A","i":"NPS12","id":288.8996,"od":323.85},{"m":"350A","i":"NPS14","id":317.5,"od":355.6},{"m":"400A","i":"NPS16","id":363.5248,"od":406.4},{"m":"450A","i":"NPS18","id":409.5496,"od":457.2},{"m":"500A","i":"NPS20","id":455.6252,"od":508}],"6":[{"m":"15A","i":"NPS1/2","id":11.7856,"od":21.336},{"m":"20A","i":"NPS3/4","id":15.5448,"od":26.67},{"m":"25A","i":"NPS1","id":20.701,"od":33.401},{"m":"32A","i":"NPS1 1/4","id":29.464,"od":42.164},{"m":"40A","i":"NPS1 1/2","id":33.9852,"od":48.26},{"m":"50A","i":"NPS2","id":42.8498,"od":60.325},{"m":"65A","i":"NPS2 1/2","id":53.975,"od":73.025},{"m":"80A","i":"NPS3","id":66.6496,"od":88.9},{"m":"100A","i":"NPS4","id":87.3252,"od":114.3},{"m":"125A","i":"NPS5","id":109.5502,"od":141.3002},{"m":"150A","i":"NPS6","id":131.7498,"od":168.275},{"m":"200A","i":"NPS8","id":173.0502,"od":219.075},{"m":"250A","i":"NPS10","id":215.9,"od":273.05},{"m":"300A","i":"NPS12","id":257.2004,"od":323.85},{"m":"350A","i":"NPS14","id":284.1752,"od":355.6},{"m":"400A","i":"NPS16","id":325.4248,"od":406.4},{"m":"450A","i":"NPS18","id":366.7252,"od":457.2},{"m":"500A","i":"NPS20","id":407.9748,"od":508}],"7":[{"m":"6A","i":"NPS1/8","id":7,"od":10.2},{"m":"8A","i":"NPS1/4","id":9.9,"od":13.5},{"m":"10A","i":"NPS3/8","id":13.6,"od":17.2},{"m":"15A","i":"NPS1/2","id":17.3,"od":21.3},{"m":"20A","i":"NPS3/4","id":22.3,"od":26.9},{"m":"25A","i":"NPS1","id":28.5,"od":33.7},{"m":"32A","i":"NPS1 1/4","id":37.2,"od":42.4},{"m":"40A","i":"NPS1 1/2","id":43.1,"od":48.3},{"m":"50A","i":"NPS2","id":54.5,"od":60.3},{"m":"65A","i":"NPS2 1/2","id":70.3,"od":76.1},{"m":"80A","i":"NPS3","id":82.5,"od":88.9},{"m":"100A","i":"NPS4","id":107.1,"od":114.3},{"m":"125A","i":"NPS5","id":131.7,"od":139.7},{"m":"150A","i":"NPS6","id":159.3,"od":168.3},{"m":"200A","i":"NPS8","id":207.3,"od":219.1},{"m":"250A","i":"NPS10","id":260.4,"od":273},{"m":"300A","i":"NPS12","id":309.7,"od":323.9},{"m":"350A","i":"NPS14","id":339.6,"od":355.6},{"m":"400A","i":"NPS16","id":388.8,"od":406.4},{"m":"450A","i":"NPS18","id":437.2,"od":457.2},{"m":"500A","i":"NPS20","id":486,"od":508}]};
  var GRADES=["JIS-SGP","JIS-STPG Sch40","JIS-STPG Sch60","JIS-STPG Sch80","ANSI Sch40","ANSI Sch80","ANSI Sch160","DIN 2448"];
  if(typeof window!=="undefined"){window.PIPE_TABLE=T;window.PIPE_GRADES=GRADES;}
  if(typeof module!=="undefined"&&module.exports){module.exports={table:T,grades:GRADES};}
})();

/*
 * IAPWS-IF97 — свойства воды и водяного пара (офлайн, без сети).
 * Реализованы области: 1 (жидкость), 2 (пар/перегретый), 4 (линия насыщения).
 * Источник: "Revised Release on the IAPWS Industrial Formulation 1997".
 *
 * Внутренние единицы: давление p — МПа, температура T — К.
 * Возвращаемые величины: v (м³/кг), h (кДж/кг), s (кДж/(кг·К)).
 *
 * Файл конкатенируется в build/js/main.js — НЕ использовать import/export.
 * Наружу отдаётся глобал window.SteamProps (и module.exports для тестов в node).
 */
(function () {
  'use strict';

  var R = 0.461526; // кДж/(кг·К), удельная газовая постоянная воды по IF97

  // ---------- Область 1: сжатая жидкость ----------
  var R1 = [
    [0, -2, 0.14632971213167], [0, -1, -0.84548187169114], [0, 0, -0.37563603672040e1],
    [0, 1, 0.33855169168385e1], [0, 2, -0.95791963387872], [0, 3, 0.15772038513228],
    [0, 4, -0.16616417199501e-1], [0, 5, 0.81214629983568e-3], [1, -9, 0.28319080123804e-3],
    [1, -7, -0.60706301565874e-3], [1, -1, -0.18990068218419e-1], [1, 0, -0.32529748770505e-1],
    [1, 1, -0.21841717175414e-1], [1, 3, -0.52838357969930e-4], [2, -3, -0.47184321073267e-3],
    [2, 0, -0.30001780793026e-3], [2, 1, 0.47661393906987e-4], [2, 3, -0.44141845330846e-5],
    [2, 17, -0.72694996297594e-15], [3, -4, -0.31679644845054e-4], [3, 0, -0.28270797985312e-5],
    [3, 6, -0.85205128120103e-9], [4, -5, -0.22425281908000e-5], [4, -2, -0.65171222895601e-6],
    [4, 10, -0.14341729937924e-12], [5, -8, -0.40516996860117e-6], [8, -11, -0.12734301741641e-8],
    [8, -6, -0.17424871230634e-9], [21, -29, -0.68762131295531e-18], [23, -31, 0.14478307828521e-19],
    [29, -38, 0.26335781662795e-22], [30, -39, -0.11947622640071e-22], [31, -40, 0.18228094581404e-23],
    [32, -41, -0.93537087292458e-25]
  ];

  function region1(p, T) {
    var pi = p / 16.53, tau = 1386 / T;
    var g = 0, gp = 0, gt = 0;
    for (var i = 0; i < R1.length; i++) {
      var I = R1[i][0], J = R1[i][1], n = R1[i][2];
      var a = Math.pow(7.1 - pi, I), b = Math.pow(tau - 1.222, J);
      g += n * a * b;
      gp += -n * I * Math.pow(7.1 - pi, I - 1) * b;
      gt += n * a * J * Math.pow(tau - 1.222, J - 1);
    }
    return {
      v: R * T / p / 1000 * pi * gp, // p в МПа → *1000 кПа; R*T/p даёт м³/кг при p в кПа
      h: R * T * tau * gt,
      s: R * (tau * gt - g)
    };
  }

  // ---------- Область 2: пар (насыщенный/перегретый) ----------
  var R2_0 = [
    [0, -0.96927686500217e1], [1, 0.10086655968018e2], [-5, -0.56087911283020e-2],
    [-4, 0.71452738081455e-1], [-3, -0.40710498223928], [-2, 0.14240819171444e1],
    [-1, -0.43839511319450e1], [2, -0.28408632460772], [3, 0.21268463753307e-1]
  ];
  var R2_r = [
    [1, 0, -0.17731742473213e-2], [1, 1, -0.17834862292358e-1], [1, 2, -0.45996013696365e-1],
    [1, 3, -0.57581259083432e-1], [1, 6, -0.50325278727930e-1], [2, 1, -0.33032641670203e-4],
    [2, 2, -0.18948987516315e-3], [2, 4, -0.39392777243355e-2], [2, 7, -0.43797295650573e-1],
    [2, 36, -0.26674547914087e-4], [3, 0, 0.20481737692309e-7], [3, 1, 0.43870667284435e-6],
    [3, 3, -0.32277677238570e-4], [3, 6, -0.15033924542148e-2], [3, 35, -0.40668253562649e-1],
    [4, 1, -0.78847309559367e-9], [4, 2, 0.12790717852285e-7], [4, 3, 0.48225372718507e-6],
    [5, 7, 0.22922076337661e-5], [6, 3, -0.16714766451061e-10], [6, 16, -0.21171472321355e-2],
    [6, 35, -0.23895741934104e2], [7, 0, -0.59059564324270e-17], [7, 11, -0.12621808899101e-5],
    [7, 25, -0.38946842435739e-1], [8, 8, 0.11256211360459e-10], [8, 36, -0.82311340897998e1],
    [9, 13, 0.19809712802088e-7], [10, 4, 0.10406965210174e-18], [10, 10, -0.10234747095929e-12],
    [10, 14, -0.10018179379511e-8], [16, 29, -0.80882908646985e-10], [16, 50, 0.10693031879409],
    [18, 57, -0.33662250574171], [20, 20, 0.89185845355421e-24], [20, 35, 0.30629316876232e-12],
    [20, 48, -0.42002467698208e-5], [21, 21, -0.59056029685639e-25], [22, 53, 0.37826947613457e-5],
    [23, 39, -0.12768608934681e-14], [24, 26, 0.73087610595061e-28], [24, 40, 0.55414715350778e-16],
    [24, 58, -0.94369707241210e-6]
  ];

  function region2(p, T) {
    var pi = p / 1.0, tau = 540 / T;
    // идеальная часть
    var g0 = Math.log(pi), g0p = 1 / pi, g0t = 0;
    for (var i = 0; i < R2_0.length; i++) {
      var J = R2_0[i][0], n = R2_0[i][1];
      g0 += n * Math.pow(tau, J);
      g0t += n * J * Math.pow(tau, J - 1);
    }
    // остаточная часть
    var gr = 0, grp = 0, grt = 0;
    for (var k = 0; k < R2_r.length; k++) {
      var I = R2_r[k][0], Jr = R2_r[k][1], nr = R2_r[k][2];
      var pp = Math.pow(pi, I), tt = Math.pow(tau - 0.5, Jr);
      gr += nr * pp * tt;
      grp += nr * I * Math.pow(pi, I - 1) * tt;
      grt += nr * pp * Jr * Math.pow(tau - 0.5, Jr - 1);
    }
    return {
      v: R * T / p / 1000 * pi * (g0p + grp),
      h: R * T * tau * (g0t + grt),
      s: R * (tau * (g0t + grt) - (g0 + gr))
    };
  }

  // Изобарная теплоёмкость cp (кДж/кг·К) перегретого пара, область 2.
  function region2cp(p, T) {
    var pi = p, tau = 540 / T;
    var g0tt = 0;
    for (var i = 0; i < R2_0.length; i++) {
      var J = R2_0[i][0], n = R2_0[i][1];
      g0tt += n * J * (J - 1) * Math.pow(tau, J - 2);
    }
    var grtt = 0;
    for (var k = 0; k < R2_r.length; k++) {
      var I = R2_r[k][0], Jr = R2_r[k][1], nr = R2_r[k][2];
      grtt += nr * Math.pow(pi, I) * Jr * (Jr - 1) * Math.pow(tau - 0.5, Jr - 2);
    }
    return -R * tau * tau * (g0tt + grtt);
  }

  // ---------- Область 4: линия насыщения ----------
  var N = [0, 0.11670521452767e4, -0.72421316703206e6, -0.17073846940092e2,
    0.12020824702470e5, -0.32325550322333e7, 0.14915108613530e2, -0.48232657361591e4,
    0.40511340542057e6, -0.23855557567849, 0.65017534844798e3];

  // Давление насыщения (МПа) по температуре (К)
  function psat(T) {
    var th = T + N[9] / (T - N[10]);
    var A = th * th + N[1] * th + N[2];
    var B = N[3] * th * th + N[4] * th + N[5];
    var C = N[6] * th * th + N[7] * th + N[8];
    var p = 2 * C / (-B + Math.sqrt(B * B - 4 * A * C));
    return Math.pow(p, 4);
  }

  // Температура насыщения (К) по давлению (МПа)
  function tsat(p) {
    var beta = Math.pow(p, 0.25);
    var E = beta * beta + N[3] * beta + N[6];
    var F = N[1] * beta * beta + N[4] * beta + N[7];
    var G = N[2] * beta * beta + N[5] * beta + N[8];
    var D = 2 * G / (-F - Math.sqrt(F * F - 4 * E * G));
    return (N[10] + D - Math.sqrt((N[10] + D) * (N[10] + D) - 4 * (N[9] + N[10] * D))) / 2;
  }

  // ---------- Динамическая вязкость (IAPWS 2008, без критического усиления) ----------
  // Возвращает μ в Па·с по плотности ρ (кг/м³) и температуре T (К).
  var H0 = [1.67752, 2.20462, 0.6366564, -0.241605];
  var Hij = [
    [0, 0, 5.20094e-1], [1, 0, 2.22531e-1], [2, 0, -2.81378e-1], [3, 0, 1.61913e-1], [4, 0, -3.25372e-2],
    [0, 1, 8.50895e-2], [1, 1, 9.99115e-1], [2, 1, -9.06851e-1], [3, 1, 2.57399e-1],
    [0, 2, -1.08374], [1, 2, 1.88797], [2, 2, -7.72479e-1],
    [0, 3, -2.89555e-1], [1, 3, 1.26613], [2, 3, -4.89837e-1], [3, 3, 6.98452e-2], [6, 3, -4.35673e-3],
    [2, 4, -2.57040e-1], [5, 4, 8.72102e-3],
    [1, 5, 1.20573e-1], [6, 5, -5.93264e-4]
  ];

  function viscosity(rho, T) {
    var Tc = 647.096, rhoc = 322.0;
    var Tb = T / Tc, rb = rho / rhoc;
    var s = 0;
    for (var i = 0; i < 4; i++) s += H0[i] / Math.pow(Tb, i);
    var mu0 = 100 * Math.sqrt(Tb) / s;
    var sum = 0;
    for (var k = 0; k < Hij.length; k++) {
      sum += Math.pow(1 / Tb - 1, Hij[k][0]) * Hij[k][2] * Math.pow(rb - 1, Hij[k][1]);
    }
    var mu1 = Math.exp(rb * sum);
    return mu0 * mu1 * 1e-6; // мкПа·с -> Па·с
  }

  // ---------- Публичный API ----------
  var SteamProps = {
    R: R,
    Tsat: tsat,          // (p[МПа]) -> T[К]
    Psat: psat,          // (T[К])   -> p[МПа]
    region1: region1,
    region2: region2,
    // Свойства насыщенной жидкости при давлении p[МПа]
    satLiquid: function (p) { return region1(p, tsat(p)); },
    // Свойства сухого насыщенного пара при давлении p[МПа]
    satVapor: function (p) { return region2(p, tsat(p)); },
    // Скрытая теплота парообразования ΔH (кДж/кг) при давлении p[МПа]
    latentHeat: function (p) { return region2(p, tsat(p)).h - region1(p, tsat(p)).h; },
    // Перегретый пар по давлению p[МПа] и температуре T[К]
    superheated: function (p, T) { return region2(p, T); },
    // Изобарная теплоёмкость cp[кДж/кг·К] перегретого пара
    cpSuperheated: region2cp,
    // Динамическая вязкость μ[Па·с] по плотности ρ[кг/м³] и T[К]
    viscosity: viscosity
  };

  if (typeof window !== 'undefined') window.SteamProps = SteamProps;
  if (typeof module !== 'undefined' && module.exports) module.exports = SteamProps;
})();

/*
 * Конверсия единиц измерения для калькуляторов.
 * В units.json из APK множителей нет (только символы), поэтому коэффициенты заданы здесь.
 * Каждая категория приводит значение к своей базовой СИ-единице (toSI) и обратно (fromSI).
 * Символы единиц совпадают с текстом .form-radio-name в выпадающих списках форм.
 * Конкатенируется в build/js/main.js — без import/export.
 *
 * Базовые единицы СИ по категориям:
 *   pressureAbs -> МПа (абсолютное)   |  dPress -> Па      |  temp -> К
 *   massFlow    -> кг/ч               |  length -> м       |  velocity -> м/с
 */
(function () {
  'use strict';

  // Разбор числа из поля ввода: принимаем и точку, и запятую как десятичный разделитель
  // (пользователи вводят "14,5"); пробелы-разделители тысяч игнорируем.
  function parseNum(value) {
    if (typeof value !== 'string') value = String(value == null ? '' : value);
    return parseFloat(value.replace(/\s+/g, '').replace(',', '.'));
  }

  var ATM = 0.101325; // атмосферное давление, МПа

  // Абсолютное/манометрическое давление -> МПа абс.  {f: множитель в МПа, off: добавка (атм для манометрических)}
  var pressureAbs = {
    'kPa abs': { f: 0.001, off: 0 }, 'MPa abs': { f: 1, off: 0 }, 'psi abs': { f: 0.00689476, off: 0 },
    'bar abs': { f: 0.1, off: 0 }, 'kg/cm² abs': { f: 0.0980665, off: 0 }, 'mmHg abs': { f: 0.000133322, off: 0 },
    'kPaG': { f: 0.001, off: ATM }, 'MPaG': { f: 1, off: ATM }, 'psig': { f: 0.00689476, off: ATM },
    'barG': { f: 0.1, off: ATM }, 'kg/cm²G': { f: 0.0980665, off: ATM }, 'mmHgG': { f: 0.000133322, off: ATM }
  };
  // Перепад/потери давления -> Па (без gauge)
  var dPress = {
    'kPa': 1000, 'MPa': 1e6, 'psi': 6894.76, 'bar': 1e5, 'kg/cm²': 98066.5, 'mmHg': 133.322, 'Pa': 1
  };
  // Массовый расход -> кг/ч
  var massFlow = { 'kg/h': 1, 't(metric)/h': 1000, 'lb/h': 0.453592 };
  // Масса -> кг
  var mass = { 'kg': 1, 'g': 0.001, 't(metric)': 1000, 'lb': 0.453592 };
  // Время -> часы
  var time = { 'h': 1, 'min': 1 / 60, 'sec': 1 / 3600 };
  // Объём -> м³
  var volume = {
    'm³': 1, 'mm³': 1e-9, 'cm³(=mL)': 1e-6, 'cm³': 1e-6, 'dm³(=L)': 0.001, 'L': 0.001, 'l': 0.001,
    'gal': 0.00378541, 'gal (US)': 0.00378541, 'gal (UK)': 0.00454609,
    'in³': 1.6387064e-5, 'ft³': 0.0283168466, 'yd³': 0.764554858, 'barrel': 0.158987295
  };
  // Длина / шероховатость -> м
  var length = { 'mm': 0.001, 'cm': 0.01, 'm': 1, 'in': 0.0254, 'ft': 0.3048, 'yd': 0.9144 };
  // Скорость -> м/с
  var velocity = { 'm/s': 1, 'ft/s': 0.3048, 'km/h': 0.277777778, 'mile/h': 0.44704 };
  // Коэффициент пропускной способности клапана -> Cv(US).  Kv = 0.865·Cv(US); Cv(UK) на имп. галлонах.
  var cv = { 'Cv(US)': 1, 'Cv': 1, 'Cv(UK)': 1.20095, 'Kv': 1.15607 };
  // Удельная теплоёмкость -> кДж/(кг·К). 1 ккал/кг°C = 1 BTU/lb°F = 4.1868 кДж/кг·К.
  var specHeat = { 'kJ/kg K': 1, 'kJ/kg·K': 1, 'kcal/kg·°C': 4.1868, 'BTU/lb °F': 4.1868 };
  // Удельная энтальпия/теплота -> кДж/кг.
  var enthalpy = { 'kJ/kg': 1, 'kcal/kg': 4.1868, 'BTU/lb': 2.326 };
  // Удельный объём -> м³/кг.
  var specVol = { 'm³/kg': 1, 'L/kg': 0.001, 'cm³/g': 0.001, 'ft³/lb': 0.0624279606 };
  // Динамическая вязкость -> мПа·с.
  var dynVisc = { 'mPa·s': 1, 'Pa·s': 1000, 'cP': 1, 'µPa·s': 0.001 };
  // Тепловой поток / мощность -> Вт.
  var power = { 'W': 1, 'kW': 1000, 'kcal/h': 1.163, 'BTU/h': 0.293071 };
  // Площадь -> м².
  var area = { 'm²': 1, 'cm²': 1e-4, 'mm²': 1e-6, 'in²': 6.4516e-4, 'ft²': 0.09290304, 'yd²': 0.83612736 };
  // Энергия -> кДж.
  var energy = { 'kJ': 1, 'J': 0.001, 'MJ': 1000, 'kcal': 4.1868, 'kWh': 3600, 'BTU': 1.05505585, 'ft·lbf': 0.001355818 };
  // Коэффициент теплоотдачи -> Вт/(м²·К).
  var heatTransfer = { 'W/m²K': 1, 'kcal/m²h°C': 1.163, 'BTU/ft²h°F': 5.678263 };
  // Теплопроводность -> Вт/(м·К).
  var thermalCond = { 'W/m K': 1, 'kcal/mh°C': 1.163, 'BTU/ft h°F': 1.730735 };
  // Разность температур -> К (чистый масштаб, без сдвига). 1 °F-разн = 5/9 К.
  var tempDiff = { '°C': 1, 'K': 1, '°F': 5 / 9 };

  // Таблица всех категорий для конвертора (символ -> множитель к базовой ед.).
  var TABLES = {
    pressureAbs: null, dPress: dPress, temp: null, tempDiff: tempDiff, massFlow: massFlow,
    mass: mass, length: length, area: area, volume: volume, velocity: velocity, volFlow: volFlow,
    time: time, specHeat: specHeat, enthalpy: enthalpy, specVol: specVol, dynVisc: dynVisc,
    energy: energy, power: power, heatTransfer: heatTransfer, thermalCond: thermalCond, cv: cv
  };
  // Объёмный расход -> м³/ч. Галлоны — US.
  var volFlow = { 'm³/h': 1, 'l/h': 0.001, 'gal/h': 0.00378541, 'GPM': 0.227125, 'm³/min': 60, 'l/min': 0.06, 'L/min': 0.06, 'CFM': 1.69901, 'ft³/min': 1.69901 };

  function toSI(value, category, symbol) {
    var v = parseNum(value);
    if (isNaN(v)) return NaN;
    symbol = (symbol || '').trim();
    switch (category) {
      case 'pressureAbs': { var p = pressureAbs[symbol]; return p ? v * p.f + p.off : NaN; }
      case 'dPress': return symbol in dPress ? v * dPress[symbol] : NaN;
      case 'massFlow': return symbol in massFlow ? v * massFlow[symbol] : NaN;
      case 'mass': return symbol in mass ? v * mass[symbol] : NaN;
      case 'length': return symbol in length ? v * length[symbol] : NaN;
      case 'velocity': return symbol in velocity ? v * velocity[symbol] : NaN;
      case 'cv': return symbol in cv ? v * cv[symbol] : NaN;
      case 'specHeat': return symbol in specHeat ? v * specHeat[symbol] : NaN;
      case 'enthalpy': return symbol in enthalpy ? v * enthalpy[symbol] : NaN;
      case 'specVol': return symbol in specVol ? v * specVol[symbol] : NaN;
      case 'dynVisc': return symbol in dynVisc ? v * dynVisc[symbol] : NaN;
      case 'power': return symbol in power ? v * power[symbol] : NaN;
      case 'area': return symbol in area ? v * area[symbol] : NaN;
      case 'energy': return symbol in energy ? v * energy[symbol] : NaN;
      case 'heatTransfer': return symbol in heatTransfer ? v * heatTransfer[symbol] : NaN;
      case 'thermalCond': return symbol in thermalCond ? v * thermalCond[symbol] : NaN;
      case 'tempDiff': return symbol in tempDiff ? v * tempDiff[symbol] : NaN;
      case 'volFlow': return symbol in volFlow ? v * volFlow[symbol] : NaN;
      case 'time': return symbol in time ? v * time[symbol] : NaN;
      case 'volume': return symbol in volume ? v * volume[symbol] : NaN;
      case 'temp':
        if (symbol === '°C') return v + 273.15;
        if (symbol === 'K') return v;
        if (symbol === '°F') return (v - 32) * 5 / 9 + 273.15;
        return NaN;
      default: return NaN;
    }
  }

  function fromSI(si, category, symbol) {
    symbol = (symbol || '').trim();
    switch (category) {
      case 'pressureAbs': { var p = pressureAbs[symbol]; return p ? (si - p.off) / p.f : NaN; }
      case 'dPress': return symbol in dPress ? si / dPress[symbol] : NaN;
      case 'massFlow': return symbol in massFlow ? si / massFlow[symbol] : NaN;
      case 'mass': return symbol in mass ? si / mass[symbol] : NaN;
      case 'length': return symbol in length ? si / length[symbol] : NaN;
      case 'velocity': return symbol in velocity ? si / velocity[symbol] : NaN;
      case 'cv': return symbol in cv ? si / cv[symbol] : NaN;
      case 'specHeat': return symbol in specHeat ? si / specHeat[symbol] : NaN;
      case 'enthalpy': return symbol in enthalpy ? si / enthalpy[symbol] : NaN;
      case 'specVol': return symbol in specVol ? si / specVol[symbol] : NaN;
      case 'dynVisc': return symbol in dynVisc ? si / dynVisc[symbol] : NaN;
      case 'power': return symbol in power ? si / power[symbol] : NaN;
      case 'area': return symbol in area ? si / area[symbol] : NaN;
      case 'energy': return symbol in energy ? si / energy[symbol] : NaN;
      case 'heatTransfer': return symbol in heatTransfer ? si / heatTransfer[symbol] : NaN;
      case 'thermalCond': return symbol in thermalCond ? si / thermalCond[symbol] : NaN;
      case 'tempDiff': return symbol in tempDiff ? si / tempDiff[symbol] : NaN;
      case 'volFlow': return symbol in volFlow ? si / volFlow[symbol] : NaN;
      case 'time': return symbol in time ? si / time[symbol] : NaN;
      case 'volume': return symbol in volume ? si / volume[symbol] : NaN;
      case 'temp':
        if (symbol === '°C') return si - 273.15;
        if (symbol === 'K') return si;
        if (symbol === '°F') return (si - 273.15) * 9 / 5 + 32;
        return NaN;
      default: return NaN;
    }
  }

  // Курируемые списки единиц для конвертора (без дублей-алиасов).
  var CONV_LISTS = {
    temp: ['°C', '°F', 'K'],
    tempDiff: ['°C', 'K', '°F'],
    pressureAbs: ['kPa abs', 'MPa abs', 'psi abs', 'bar abs', 'kg/cm² abs', 'mmHg abs', 'kPaG', 'MPaG', 'psig', 'barG', 'kg/cm²G', 'mmHgG'],
    length: ['mm', 'cm', 'm', 'in', 'ft', 'yd'],
    area: ['m²', 'cm²', 'mm²', 'in²', 'ft²', 'yd²'],
    volume: ['m³', 'cm³(=mL)', 'dm³(=L)', 'gal (US)', 'gal (UK)', 'in³', 'ft³', 'yd³', 'barrel'],
    velocity: ['m/s', 'km/h', 'ft/s', 'mile/h'],
    mass: ['kg', 'g', 't(metric)', 'lb'],
    dynVisc: ['mPa·s', 'Pa·s', 'cP', 'µPa·s'],
    energy: ['kJ', 'J', 'MJ', 'kcal', 'kWh', 'BTU', 'ft·lbf'],
    heatTransfer: ['W/m²K', 'kcal/m²h°C', 'BTU/ft²h°F'],
    thermalCond: ['W/m K', 'kcal/mh°C', 'BTU/ft h°F'],
    enthalpy: ['kJ/kg', 'kcal/kg', 'BTU/lb']
  };
  function list(category) {
    if (CONV_LISTS[category]) return CONV_LISTS[category].slice();
    var t = TABLES[category];
    return t ? Object.keys(t) : [];
  }

  var Units = { toSI: toSI, fromSI: fromSI, ATM: ATM, list: list, parseNum: parseNum };
  if (typeof window !== 'undefined') window.Units = Units;
  if (typeof module !== 'undefined' && module.exports) module.exports = Units;
})();


document.addEventListener("DOMContentLoaded", function () {

  document.querySelectorAll('.dropdown').forEach(function (dropDownWrapper) {
    const dropDownBtn  = dropDownWrapper.querySelector('.dropdown__button');
    const dropDownList = dropDownWrapper.querySelector('.dropdown__list');

    const inputs = dropDownWrapper.querySelectorAll('input[type="radio"], input[type="checkbox"]');
    if (!inputs.length) return;

    const placeholder = dropDownWrapper.dataset.placeholder || dropDownBtn.textContent.trim();

    function openDropdown() {
      dropDownList.style.height = (dropDownList.scrollHeight + 1) + 'px';
      dropDownList.classList.add('dropdown__list--visible');
      dropDownBtn.classList.add('dropdown__button--active');
      dropDownWrapper.classList.add('dropdown-active');
      dropDownBtn.setAttribute('aria-expanded', 'true');
    }

    function closeDropdown() {
      dropDownList.classList.remove('dropdown__list--visible');
      dropDownList.style.height = 0;
      dropDownBtn.classList.remove('dropdown__button--active');
      dropDownWrapper.classList.remove('dropdown-active');
      dropDownBtn.setAttribute('aria-expanded', 'false');
    }

    function getLabelText(input) {
      const label = input.closest('label');
		if (!label) return '';

		const textEl = label.querySelector('.form-radio-name');
		if (textEl) {
			return textEl.textContent.trim();
		}

		// fallback на случай другой разметки
		return label.textContent.trim();
    }

    function updateButtonText() {
      const checked = dropDownWrapper.querySelectorAll('input:checked');
      if (!checked.length) {
        dropDownBtn.textContent = placeholder;
        return;
      }

      // Определяем режим: radio или checkbox
      const isRadio = checked[0].type === 'radio';

      if (isRadio) {
        dropDownBtn.textContent = getLabelText(checked[0]);
      } else {
        const texts = Array.from(checked).map(getLabelText).filter(Boolean);
        dropDownBtn.textContent = texts.length ? texts.join(', ') : placeholder;
      }
    }

    // Инициализация
    updateButtonText();

    // Открыть/закрыть по кнопке
    dropDownBtn.addEventListener('click', function () {
      if (dropDownList.classList.contains('dropdown__list--visible')) {
        closeDropdown();
      } else {
        openDropdown();
      }
    });

    // Реакция на выбор
    inputs.forEach(function (input) {
      input.addEventListener('change', function () {
        updateButtonText();

        // Если radio — закрываем сразу (как селект)
        if (this.type === 'radio') {
          dropDownBtn.focus();
          closeDropdown();
        }
        // Если checkbox — обычно НЕ закрывают, чтобы можно было выбрать несколько.
        // Но если тебе нужно закрывать — скажи, добавим опцию.
      });
    });

    // Клик снаружи — закрыть
    document.addEventListener('click', function (e) {
      if (!dropDownWrapper.contains(e.target)) {
        closeDropdown();
      }
    });

    // Tab/Escape — закрыть
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Tab' || e.key === 'Escape') {
        closeDropdown();
      }
    });
  });

});


document.addEventListener("DOMContentLoaded", function () {
//MASK PHONE
const PREFIX = "+7(";
function formatPhoneFromDigits(digits) {
	digits = digits.replace(/\D/g, "").slice(0, 11); // максимум 11 цифр (включая 7)
		let out = "+7(";
		if (digits.length > 1) out += digits.slice(1, 4);
		if (digits.length >= 4) out += ")" + digits.slice(4, 7);
		if (digits.length >= 7) out += "-" + digits.slice(7, 9);
		if (digits.length >= 9) out += "-" + digits.slice(9, 11);
		return out;
	}

	function getDigitsFromMasked(v) {
		return v.replace(/\D/g, "");
	}

	function setCaret(el, pos) {
		requestAnimationFrame(() => el.setSelectionRange(pos, pos));
	}

	document.querySelectorAll("input.phone").forEach(input => {
		// Автовставка префикса
		input.addEventListener("focus", () => {
			if (!input.value) {
			input.value = PREFIX;
			setCaret(input, PREFIX.length);
			}
	});

		// Блокируем перемещение курсора левее префикса
	input.addEventListener("click", () => {
		if (input.selectionStart < PREFIX.length) setCaret(input, PREFIX.length);
	});

	// На мобилках лучше перехватывать ввод до применения
	input.addEventListener("beforeinput", (e) => {
		// Разрешаем только цифры/удаление/вставку
		const allowed = ["insertText", "deleteContentBackward", "deleteContentForward", "insertFromPaste"];
		if (!allowed.includes(e.inputType)) return;

		const selStart = input.selectionStart ?? input.value.length;
		const selEnd = input.selectionEnd ?? selStart;

			// Не даём ломать фиксированный префикс
			if (selStart < PREFIX.length && e.inputType.startsWith("delete")) {
			e.preventDefault();
			return;
			}

			const currentDigits = getDigitsFromMasked(input.value);
			// Позицию в «чистых» цифрах вычислим грубо по количеству цифр слева от курсора
			const digitsLeft = getDigitsFromMasked(input.value.slice(0, selStart)).length;
			const digitsRight = getDigitsFromMasked(input.value.slice(selEnd)).length;

			let newDigitsLeft = currentDigits.slice(0, digitsLeft);
			let newDigitsRight = currentDigits.slice(currentDigits.length - digitsRight);

			if (e.inputType === "insertText") {
			// Разрешаем только цифры
			if (!/^\d$/.test(e.data)) { e.preventDefault(); return; }
			// Лимит 11 цифр
			if ((newDigitsLeft + e.data + newDigitsRight).length > 11) { e.preventDefault(); return; }
			newDigitsLeft += e.data;
			e.preventDefault();
			} else if (e.inputType === "insertFromPaste") {
			const pasted = (e.dataTransfer?.getData("text") ?? "").replace(/\D/g, "");
			if (!pasted) { e.preventDefault(); return; }
			const room = 11 - (newDigitsLeft + newDigitsRight).length;
			newDigitsLeft += pasted.slice(0, Math.max(0, room));
			e.preventDefault();
			} else if (e.inputType === "deleteContentBackward") {
			if (newDigitsLeft.length > 0) newDigitsLeft = newDigitsLeft.slice(0, -1);
			e.preventDefault();
			} else if (e.inputType === "deleteContentForward") {
			if (newDigitsRight.length > 0) newDigitsRight = newDigitsRight.slice(1);
			e.preventDefault();
			}

			const allDigits = newDigitsLeft + newDigitsRight;
			const masked = formatPhoneFromDigits(allDigits);
			input.value = masked;

			// Ставим каретку после той цифры, которую только что вводили/удаляли
			// Находим целевую позицию по количеству цифр слева
			const targetDigitsLeft = newDigitsLeft.length;
			// Пробегаем по маске, пока не наберём targetDigitsLeft цифр
			let caret = 0, count = 0;
			while (caret < masked.length && count < targetDigitsLeft) {
			if (/\d/.test(masked[caret])) count++;
			caret++;
			}
			// Не даём залезть в префикс
			if (caret < PREFIX.length) caret = PREFIX.length;
			setCaret(input, caret);
		});

		// На всякий случай — финальный форматтер (если что-то проскочит)
      input.addEventListener("input", () => {
        const masked = formatPhoneFromDigits(getDigitsFromMasked(input.value));
        if (masked !== input.value) input.value = masked;
      });
});
// FORM VALIDATION TEMPLATE
(function initFormValidation() {
  const ERROR_CLASS = "error";
  const ERROR_TEXT_CLASS = "error-text";

  // Ищем формы (можно оставить просто "form" если одна)
  const forms = document.querySelectorAll("form.js-validate-form");

  // Если у тебя нет класса js-validate-form, можно заменить на:
  // const forms = document.querySelectorAll("form");

  forms.forEach((form) => {
    const inputs = Array.from(form.querySelectorAll("input, textarea, select"));

    function getFormItem(input) {
      return input.closest(".form-item");
    }

    function getOrCreateErrorSpan(formItem) {
      if (!formItem) return null;

      let span = formItem.querySelector(`.${ERROR_TEXT_CLASS}`);
      if (!span) {
        span = document.createElement("span");
        span.className = ERROR_TEXT_CLASS;
        formItem.appendChild(span);
      }
      return span;
    }

    function setError(input, message) {
      const formItem = getFormItem(input);

      input.classList.add(ERROR_CLASS);
      if (formItem) formItem.classList.add(ERROR_CLASS);

      const span = getOrCreateErrorSpan(formItem);
      if (span) span.textContent = message;
    }

    function clearError(input) {
      const formItem = getFormItem(input);

      input.classList.remove(ERROR_CLASS);
      if (formItem) formItem.classList.remove(ERROR_CLASS);

      if (formItem) {
        const span = formItem.querySelector(`.${ERROR_TEXT_CLASS}`);
        if (span) span.remove();
      }
    }

    function isEmptyValue(input) {
      const value = (input.value ?? "").trim();

      // для телефона с префиксом +7( — считаем пустым, если кроме цифр ничего нет или введено мало
      if (input.classList.contains("phone")) {
        const digits = value.replace(/\D/g, "");
        // digits будет типа "7" если только префикс
        return digits.length <= 1;
      }

      return value.length === 0;
    }

    function validateEmailOnBlur(input) {
      // требование из задачи: если нет "@" => ошибка
      const v = (input.value ?? "").trim();
      if (v && !v.includes("@")) {
        setError(input, "Не верное значение");
      } else {
        // если исправили — снимаем ошибку
        clearError(input);
      }
    }

    // --- EVENTS ---

    // focus: "проверяем тип" — логика простая: если email, то активируем проверку на blur
    inputs.forEach((input) => {
      input.addEventListener("focus", () => {
        // ничего не делаем кроме понимания типа; проверка будет на blur
      });

      input.addEventListener("blur", () => {
        if (input.type === "email") {
          validateEmailOnBlur(input);
        }
      });

      // Чтобы ошибка уходила при исправлении
      input.addEventListener("input", () => {
        // Если уже было error — пробуем снять, когда поле стало не пустым
        if (input.classList.contains(ERROR_CLASS)) {
          // Для email — снимаем только если стало валидно по нашему правилу
          if (input.type === "email") {
            const v = (input.value ?? "").trim();
            if (!v) {
              // если пусто — пока не снимаем (submit покажет "Поле не заполнено" если required)
              clearError(input); // можно оставить/убрать — я убираю, чтобы не мешало
              return;
            }
            if (v.includes("@")) clearError(input);
          } else {
            if (!isEmptyValue(input)) clearError(input);
          }
        }
      });

      input.addEventListener("change", () => {
        if (!isEmptyValue(input)) clearError(input);
      });
    });

    // submit: required fields
    form.addEventListener("submit", (e) => {
      let hasErrors = false;

      const requiredFields = Array.from(form.querySelectorAll("[data-required]"));

      requiredFields.forEach((input) => {
        if (isEmptyValue(input)) {
          setError(input, "Поле не заполнено");
          hasErrors = true;
          return;
        }

        // Доп. проверка email при сабмите тоже (чтобы не зависело от blur)
        if (input.type === "email") {
          const v = (input.value ?? "").trim();
          if (v && !v.includes("@")) {
            setError(input, "Не верное значение");
            hasErrors = true;
            return;
          }
        }

        // если всё ок — чистим
        clearError(input);
      });

      if (hasErrors) {
        e.preventDefault();
		
  // 1) Находим первый инпут с ошибкой (можно и по .form-item.error, но так точнее)
  const firstErrorInput = form.querySelector("input.error, textarea.error, select.error");

  if (firstErrorInput) {
    // Если есть фиксированная шапка — можно добавить отступ
    const HEADER_OFFSET = 0; // например 80

    const y = firstErrorInput.getBoundingClientRect().top + window.pageYOffset - HEADER_OFFSET;

    window.scrollTo({
      top: y,
      behavior: "smooth",
    });

    // 2) Фокус в поле (не обязательно, но удобно)
    firstErrorInput.focus({ preventScroll: true });
  }
      }
    });
  });
})();

});
document.addEventListener('DOMContentLoaded', function () {
	const wrappers = document.querySelectorAll('.hide-block-wrapper');

	wrappers.forEach(function (wrapper) {
		const button = wrapper.querySelector('.open-hide-btn');
		const hiddenBlock = wrapper.querySelector('.is-hide-block');

		if (!button || !hiddenBlock) return;

		button.addEventListener('click', function () {
			const isOpen = wrapper.classList.contains('is-open');

				if (isOpen) {
					closeBlock(wrapper, hiddenBlock);
					button.querySelector('.hide-btn-txt').textContent = 'Показать дополнительные опции';
				} else {
					openBlock(wrapper, hiddenBlock);
					button.querySelector('.hide-btn-txt').textContent = 'Скрыть дополнительные опции';
				}
		});
		
	});

	function openBlock(wrapper, block) {
		wrapper.classList.add('is-open');

		block.style.height = block.scrollHeight + 'px';

		block.addEventListener('transitionend', function handler(e) {
			if (e.propertyName !== 'height') return;

			block.style.height = 'auto';
			block.removeEventListener('transitionend', handler);
		});
	}

	function closeBlock(wrapper, block) {
		block.style.height = block.scrollHeight + 'px';

		// Нужно, чтобы браузер успел применить текущую высоту
		block.offsetHeight;

		block.style.height = '0px';
		wrapper.classList.remove('is-open');
	}
});
// Удаляет тяжёлые блоки калькуляторов из DOM на экранах <=767px и возвращает
// их на место при возврате к десктопу. Запускается ПОСЛЕ acordion-menu.js
// (алфавитный порядок конкатенации), чтобы слушатели .acc__head успели
// привязаться к кнопкам внутри .grid-column-sidebar до того, как контейнер
// будет отсоединён — replaceWith сохраняет узел и его слушатели.
(function () {
  const mql = window.matchMedia("(max-width: 767px)");

  const targets = [
    ...document.querySelectorAll(".calc-start-page .grid-column-main"),
    ...document.querySelectorAll(".calculator-single .grid-column-sidebar"),
  ].map((node) => ({
    node,
    placeholder: document.createComment("mobile-detached"),
  }));

  function apply(isMobile) {
    targets.forEach(({ node, placeholder }) => {
      if (isMobile) {
        if (node.isConnected) node.replaceWith(placeholder);
      } else {
        if (placeholder.isConnected) placeholder.replaceWith(node);
      }
    });
  }

  apply(mql.matches);
  mql.addEventListener("change", (e) => apply(e.matches));
})();
